package com.example.hady.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

val PastelBlue = Color(0xFFB4E4FF)   // Pastelová modrá
val PastelOrange = Color(0xFFFFE0B2) // Pastelová oranžová
val PastelPink = Color(0xFFFFC1E3)   // Pastelová ružová
val PastelGreen = Color(0xFFA5D6A7)  // Pastelová zelená
val PastelYellow = Color(0xFFFFF59D) // Pastelová žltá
val PastelPurple = Color(0xFFD1C4E9) // Pastelová fialová
val PastelTeal = Color(0xFFB2DFDB)   // Pastelová tyrkysová
val PastelRed = Color(0xFFFFABAB)    // Pastelová červená
val PastelBeige = Color(0xFFFFE4C4)  // Pastelová béžová
val PastelMint = Color(0xFFCCFFCC)   // Pastelová mentolová