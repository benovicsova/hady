package com.example.hady

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.*

import com.example.hady.ui.MainScreen
import com.example.hady.ui.EditorScreen
import com.example.hady.ui.HomeScreen
import com.example.hady.ui.theme.HadyTheme
import com.example.hady.logic.HadViewModel
import com.example.hady.logic.Solver

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {

            HadyTheme {
                val navController = rememberNavController()
                val viewModel: HadViewModel = viewModel()

                NavHost(navController = navController, startDestination = "home_screen") {
                    composable("home_screen") {
                        HomeScreen(navController, viewModel)
                    }
                    composable("main_screen") {
                        MainScreen(navController, viewModel)
                    }
                    composable("editor_screen") {
                        EditorScreen(navController, viewModel)
                    }
                }
            }
        }
    }
}
