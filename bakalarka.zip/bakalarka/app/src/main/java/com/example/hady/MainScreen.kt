    package com.example.hady.ui

    import HadUI
    import android.annotation.SuppressLint
    import android.util.Log
    import androidx.compose.foundation.Image
    import androidx.compose.foundation.background
    import androidx.compose.foundation.border
    import androidx.compose.foundation.layout.Box
    import androidx.compose.material3.IconButton
    import androidx.compose.runtime.*
    import androidx.compose.ui.graphics.Color
    import androidx.lifecycle.viewmodel.compose.viewModel
    import androidx.navigation.NavController
    import com.example.hady.ui.theme.HadyTheme
    import com.example.hady.ui.theme.PastelBlue
    import androidx.compose.foundation.layout.*
    import androidx.compose.foundation.shape.CircleShape
    import androidx.compose.foundation.shape.RoundedCornerShape
    import androidx.compose.material.icons.Icons
    import androidx.compose.material.icons.filled.Edit
    import androidx.compose.material.icons.filled.Home
    import androidx.compose.material3.*
    import androidx.compose.ui.Alignment
    import androidx.compose.ui.Modifier
    import androidx.compose.ui.draw.clip
    import androidx.compose.ui.layout.ContentScale
    import androidx.compose.ui.platform.LocalConfiguration
    import androidx.compose.ui.platform.LocalContext
    import androidx.compose.ui.res.painterResource
    import androidx.compose.ui.unit.dp
    import com.example.hady.R
    import com.example.hady.logic.Generator
    import com.example.hady.logic.Had
    import com.example.hady.ui.theme.PastelGreen
    import com.example.hady.ui.theme.PastelOrange
    import com.example.hady.ui.theme.PastelPink
    import com.example.hady.ui.theme.PastelYellow
    import com.example.hady.logic.HadViewModel

    @Composable
    fun MainScreen(
        navController: NavController,
        viewModel: HadViewModel = viewModel()
    ) {
        val had by viewModel.had
        val hadCopy by viewModel.hadCopy
        val selectedButtonIndex by viewModel.selectedButtonIndex
        val context = LocalContext.current

        val currentLevelIndex = viewModel.currentLevel
        val currentLevelColor = viewModel.levels.getOrElse(viewModel.currentLevel) { PastelBlue }

        val configuration = LocalConfiguration.current
        val isLandscape =
            configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE

        val buttonSize = if (!isLandscape) 60.dp else 30.dp
        val iconSize = if (!isLandscape) 40.dp else 30.dp
        val padding = if (!isLandscape) 15.dp else 20.dp

        LaunchedEffect(Unit) {
            viewModel.initializePreferences(context)
        }


        HadyTheme {
            Box(modifier = Modifier.fillMaxSize()
                .padding(WindowInsets.statusBars.asPaddingValues())) {

                Image(
                    painter = painterResource(id = R.drawable.background),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                IconButton(
                    onClick = {
                        navController.navigate("home_screen")
                        viewModel.editorMode.value = 0
                    },
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(top = padding, start = padding)
                        .size(buttonSize)
                        .border(1.dp, Color.Black, shape = RoundedCornerShape(20.dp))
                        .background(viewModel.levels[viewModel.currentLevel], shape = RoundedCornerShape(20.dp))
                ) {
                    Icon(
                        imageVector = Icons.Filled.Home,
                        contentDescription = "Home",
                        tint = Color.White,
                        modifier = Modifier.size(iconSize)
                    )
                }

                HadUI(
                    had = had,
                    hadCopy = hadCopy,
                    onColorSelected = { _, index ->
                        viewModel.selectedButtonIndex.value = index
                    },
                    viewModel = viewModel
                )

                if (viewModel.had.value.pomocnySucet != null) {
                    SumUI(had = had, viewModel = viewModel,
                        onColorSelected = { _, index ->
                            viewModel.selectedButtonIndex.value = index
                        })
                }


                if (viewModel.currentHadIndex.value >= Generator.counts[currentLevelIndex] && viewModel.currentLevel != 4) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                    ) {
                        IconButton(
                            onClick = {
                                viewModel.editorMode.value = 1
                                navController.navigate("editor_screen")
                            },
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(top = padding, end = padding)
                                .size(buttonSize)
                                .border(1.dp, Color.Black, shape = RoundedCornerShape(20.dp))
                                .background(viewModel.levels[viewModel.currentLevel], shape = RoundedCornerShape(20.dp)),
                            ) {
                            Icon(
                                imageVector = Icons.Filled.Edit,
                                contentDescription = "Edit",
                                tint = Color.White,
                                modifier = Modifier.size(iconSize)
                            )
                        }
                    }
                }

                if (viewModel.had.value.neposedy == null) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize(),
                        ) {
                        CalculatorScreen(
                            had = had,
                            hadCopy = hadCopy,
                            selectedButtonIndex = selectedButtonIndex,
                            onSelectButton = { index ->
                                viewModel.selectedButtonIndex.value = index
                            },
                            onHadChange = { update ->
                                viewModel.updateHad(update)
                            },
                            navController = navController,
                            viewModel = viewModel
                        )
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxSize(),
                        ) {
                        CalculatorScreen2(
                            had = had,
                            hadCopy = hadCopy,
                            selectedButtonIndex = selectedButtonIndex,
                            onSelectButton = { index ->
                                viewModel.selectedButtonIndex.value = index
                            },
                            onHadChange = { change -> viewModel.updateHad(change) },
                            navController = navController,
                            viewModel = viewModel
                        )
                    }
                }


                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(buttonSize)
                        .padding(horizontal = 100.dp)
                        .offset(y = padding)
                        .align(Alignment.TopCenter)
                ) {

                    LinearProgressIndicator(
                        progress = viewModel.getLevelProgress(currentLevelIndex),
                        color = currentLevelColor,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(2.dp)
                            .clip(RoundedCornerShape(20))
                            .border(1.dp, Color.Black, shape = RoundedCornerShape(20))
                    )
                }

            }
        }
    }

