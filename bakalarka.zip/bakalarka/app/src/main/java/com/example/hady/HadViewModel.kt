package com.example.hady.logic

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.compose.runtime.*
import androidx.lifecycle.ViewModel
import com.example.hady.ui.theme.PastelBlue
import com.example.hady.ui.theme.PastelGreen
import com.example.hady.ui.theme.PastelOrange
import com.example.hady.ui.theme.PastelPink
import com.example.hady.ui.theme.PastelYellow
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class HadViewModel : ViewModel() {

    private lateinit var sharedPreferences: SharedPreferences

    private val hadyLists: MutableList<MutableList<Had>> by lazy {
        mutableListOf(
            Generator.generujLevel1().toMutableList(),
            Generator.generujLevel2().toMutableList(),
            Generator.generujLevel3().toMutableList(),
            Generator.generujLevel4().toMutableList(),
            Generator.generujLevel5().toMutableList()
        )
    }

    var currentLevel by mutableStateOf(0)
    var levelProgress = mutableStateOf(List(5) { 0f })
    var levelIndices = mutableStateOf(List(5) { 0 })

    private var hadyList: List<Had> = emptyList()
    var currentHadIndex = mutableStateOf(0)
        private set
    var had = mutableStateOf(Had())
    var hadCopy = mutableStateOf(Had())
        private set

    var selectedButtonIndex = mutableStateOf(0)
    var isFinalDialogVisible = mutableStateOf(false)
    var progress = mutableStateOf(0f)

    val levels = listOf(
        PastelBlue,   // Level 1
        PastelOrange, // Level 2
        PastelPink,   // Level 3
        PastelGreen,  // Level 4
        PastelYellow  // Level 5
    )

    var editorMode = mutableStateOf(0)

    var editorMessage = mutableStateOf("")

    var unlockedLevels by mutableStateOf(mutableMapOf<Int, Boolean>())

    var removedNumbers = mutableListOf<Pair<Int, Int>>()


    var fullNumberList = List(10) {
            index -> had.value.neposedy?.getOrNull(index)?.let { index to it }
    }

    var availableNumbers =  fullNumberList.filterNotNull().toMutableList()



    fun initializePreferences(context: Context) {
        if (!::sharedPreferences.isInitialized) {
            sharedPreferences = context.getSharedPreferences("Progress", Context.MODE_PRIVATE)
        }

        levelProgress.value = List(5) { level ->
            sharedPreferences.getFloat("level_$level", 0f)
        }

        levelIndices.value = List(5) { level ->
            sharedPreferences.getInt("index_level_$level", 0)
        }

        if (currentLevel == 0) {
            loadLevel(currentLevel)
        }

        unlockedLevels = loadUnlockedLevels()


    }

    fun saveUnlockedLevels() {
        val jsonString = Gson().toJson(unlockedLevels)
        sharedPreferences.edit()
            .putString("unlocked_levels", jsonString)
            .apply()
    }

    fun loadUnlockedLevels(): MutableMap<Int, Boolean> {
        val jsonString = sharedPreferences.getString("unlocked_levels", "{}")
        return Gson().fromJson(jsonString, object : TypeToken<MutableMap<Int, Boolean>>() {}.type)
            ?: mutableMapOf()
    }

    fun unlockLevel(level: Int) {
        unlockedLevels[level] = true
        saveUnlockedLevels()
    }

    fun getLevelProgress(level: Int): Float {
        return levelProgress.value[level]
    }

    fun saveLevelProgress(level: Int, progress: Float) {
        if (!::sharedPreferences.isInitialized) return

        sharedPreferences.edit().putFloat("level_$level", progress).apply()

        levelProgress.value = levelProgress.value.toMutableList().apply {
            this[level] = progress
        }
    }

    fun saveLevelIndex(level: Int, index: Int) {
        if (!::sharedPreferences.isInitialized) return

        sharedPreferences.edit().putInt("index_level_$level", index).apply()

        levelIndices.value = levelIndices.value.toMutableList().apply {
            this[level] = index
        }
    }

    fun resetProgress() {
        if (!::sharedPreferences.isInitialized) return

        sharedPreferences.edit().clear().apply()

        levelProgress.value = List(5) { 0f }
        levelIndices.value = List(5) { 0 }

        unlockedLevels = mutableMapOf<Int, Boolean>()

        generateNewExamples()
    }

    private fun generateNewExamples() {
        hadyLists.clear()
        hadyLists.addAll(
            listOf(
                Generator.generujLevel1().toMutableList(),
                Generator.generujLevel2().toMutableList(),
                Generator.generujLevel3().toMutableList(),
                Generator.generujLevel4().toMutableList(),
                Generator.generujLevel5().toMutableList()
            )
        )
    }

    fun loadLevel(level: Int) {
        currentLevel = level

        hadyList = hadyLists[level]
        currentHadIndex.value = levelIndices.value[level]
        progress.value = getLevelProgress(level)

        loadCurrentHad()
    }

    private fun loadCurrentHad() {
        if (editorMode.value == 1) {
            Log.d("TAG", "SOM V EDITOR 2")
            Log.d("TAG", "neposedky: ${had.value.neposedy}")
            val aktualnyHad = had.value
            had.value = aktualnyHad.copy(
                pomocnySucet = aktualnyHad.pomocnySucet,
                neposedy = aktualnyHad.neposedy
            )
            hadCopy.value = aktualnyHad.copy(
                pomocnySucet = aktualnyHad.pomocnySucet,
                neposedy = aktualnyHad.neposedy
            )
            had.value.pomocnySucet = aktualnyHad.pomocnySucet
            had.value.neposedy = aktualnyHad.neposedy
            selectedButtonIndex.value = getFirstEmptyIndex(had.value)
            progress.value = currentHadIndex.value.toFloat() / Generator.counts[currentLevel]
            if (had.value.neposedy != null) {
                fullNumberList = List(10) {
                        index -> had.value.neposedy?.getOrNull(index)?.let { index to it }
                }
                Log.d("TAG", "fullNumberList: $fullNumberList")
                availableNumbers = fullNumberList.filterNotNull().toMutableList()
            }
        }
        else if (currentHadIndex.value < hadyList.size) {
            Log.d("TAG", "SOM V DRUHOM")
            val aktualnyHad = hadyList[currentHadIndex.value]
            had.value = aktualnyHad.copy(
                pomocnySucet = aktualnyHad.pomocnySucet,
                neposedy = aktualnyHad.neposedy
            )
            hadCopy.value = aktualnyHad.copy(
                pomocnySucet = aktualnyHad.pomocnySucet,
                neposedy = aktualnyHad.neposedy
            )
            had.value.pomocnySucet = aktualnyHad.pomocnySucet
            had.value.neposedy = aktualnyHad.neposedy
            Log.d("TAG", "had.value: ${aktualnyHad.neposedy}")
            selectedButtonIndex.value = getFirstEmptyIndex(had.value)
            progress.value = currentHadIndex.value.toFloat() / Generator.counts[currentLevel]
            if (had.value.neposedy != null) {
                fullNumberList = List(10) {
                        index -> had.value.neposedy?.getOrNull(index)?.let { index to it }
                }
                Log.d("TAG", "fullNumberList: $fullNumberList")
                availableNumbers = fullNumberList.filterNotNull().toMutableList()
            }
        } else {
            nextHad()
        }
    }

    fun nextHad() {
        if (currentHadIndex.value < hadyList.size - 1) {
            currentHadIndex.value += 1
            loadCurrentHad()

            saveLevelProgress(currentLevel, progress.value)
            saveLevelIndex(currentLevel, currentHadIndex.value)
        } else {
            isFinalDialogVisible.value = true
            progress.value = 1.0f
            val newHad = when (currentLevel) {
                0 -> Generator.generujU4L1()
                1 -> Generator.generujU4L2()
                2 -> Generator.generujU3L3()
                3 -> Generator.generujU3L4()
                else -> Generator.generujU4L5()
            }

            hadyLists[currentLevel].add(newHad)
            hadyList =  hadyLists[currentLevel]
            currentHadIndex.value = hadyList.lastIndex
            loadCurrentHad()

            saveLevelProgress(currentLevel, 1.0f)
            saveLevelIndex(currentLevel, currentHadIndex.value)
        }
    }

    fun getFirstEmptyIndex(had: Had): Int {
        for (i in had.sucet.indices) {
            if (had.sucet[i] == null) return i * 3
            if (i < had.operatory.size && (had.operatory[i] == null || had.operatory[i] == Operator.REVERSE)) return i * 3 + 1
            if (i < had.operandy.size && had.operandy[i] == null) return i * 3 + 2
        }
        return -1
    }

    fun updateHad(update: Had.() -> Unit) {
        val newHad = had.value.copy()
        newHad.update()
        had.value = newHad
    }

    fun updateSelectedButtonIndex() {
        selectedButtonIndex.value = getFirstEmptyIndex(had.value)
        }

    fun vymazNeposeda(selectedButtonIndex : Int) {
        val newHad = had.value.copy()
        if (selectedButtonIndex%3 == 0) {
            val currentNumber = had.value.sucet[selectedButtonIndex / 3]
            if (currentNumber != null) {
                val removedIndex = removedNumbers.indexOfFirst { it.second == currentNumber }
                if (removedIndex != -1) {
                    val restoredPair = removedNumbers.removeAt(removedIndex)
                    availableNumbers.add(restoredPair)
                }
                newHad.sucet[selectedButtonIndex / 3] = null
            }
        } else {
            val currentNumber = had.value.operandy[selectedButtonIndex / 3]
            if (currentNumber != null) {
                val removedIndex = removedNumbers.indexOfFirst { it.second == currentNumber }
                if (removedIndex != -1) {
                    val restoredPair = removedNumbers.removeAt(removedIndex)
                    availableNumbers.add(restoredPair)
                }
                newHad.operandy[selectedButtonIndex / 3] = null
            }
        }
        had.value = newHad
    }
}