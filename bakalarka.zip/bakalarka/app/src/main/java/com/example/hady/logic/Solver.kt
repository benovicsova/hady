package com.example.hady.logic

import android.util.Log
import java.util.logging.Logger
import com.example.hady.logic.HadViewModel

class Solver {

    companion object {

        fun isSolvable(had: Had): Pair<Boolean, String?> {

            var vyslednyHad = had.copy()

            var queue = mutableListOf<Int>()

            if (vyslednyHad.neposedy != null){
                if (jeVyplneny(vyslednyHad)) {
                    if (vyslednyHad.check()) {
                        return Pair(true, null)
                    } else {
                        return Pair(false, "Had nie je správne vyplnený")
                    }
                } else {
                    return Pair(false, "Nie sú vyplnené všetky políčka")
                }
            }

            if (jeVyplneny(vyslednyHad)) return Pair(false, "Had je už celý vyplnený")


            if (vyslednyHad.pomocnySucet!=null){
                val sucet = vyslednyHad.pomocnySucet!!.second

                if (sucet == null){
                    Log.d("pomoc","pomocny sucet je ${vyslednyHad.pomocnySucet}")
                    return Pair(false, "Doplň pomocný súčet")
                }

                val index1 = vyslednyHad.pomocnySucet!!.first.first / 3
                val index2 = vyslednyHad.pomocnySucet!!.first.second / 3

                val operand = vyslednyHad.operandy[index1]
                val operator = vyslednyHad.operatory[index1]

                if (vyslednyHad.sucet[index1] != null && vyslednyHad.sucet[index2] != null){
                    if (vyslednyHad.sucet[index1]!! + vyslednyHad.sucet[index2]!! != sucet){
                        return Pair(false, "Nesedí pomocný súčet")
                    }
                } else if (vyslednyHad.sucet[index1] != null){
                    vyslednyHad.sucet[index2] = sucet - vyslednyHad.sucet[index1]!!
                } else if (vyslednyHad.sucet[index2] != null){
                    vyslednyHad.sucet[index1] = sucet - vyslednyHad.sucet[index2]!!
                } else if (operand != null){
                    if (operand > sucet){
                        return Pair(false, "Had sa nedá vyriešiť")
                    } else if (operand % 2 != sucet % 2){
                        return Pair(false, "Had sa nedá vyriešiť")
                    } else {
                        val zaklad = (sucet - operand) / 2
                        if (operator == Operator.ADD){
                            vyslednyHad.sucet[index1] = zaklad
                            vyslednyHad.sucet[index2] = zaklad + operand
                        } else {
                            vyslednyHad.sucet[index2] = zaklad
                            vyslednyHad.sucet[index1] = zaklad + operand
                        }
                    }
                }
            }

            try {

                //prejdem hada po usekoch
                for (i in 0 until vyslednyHad.sucet.size - 1) {

                    val (novyHad, novaQueue) = vyriesUsek(vyslednyHad, i, queue)

                    vyslednyHad = novyHad
                    queue = novaQueue
                }

            } catch (e: HadException) {
                return Pair(false,e.message)
            }

            if (queue.isEmpty()) {
                if (sediPom(vyslednyHad)) {
                    return Pair(true, null)
                } else {
                    return Pair(false, "Nesedí pomocný súčet")
                }
            }

            //druhykrat prejdem
            var dlzka = queue.size
            for (i in 0 until dlzka) {
                val index = queue.removeAt(0)
                val (novyHad, novaQueue) = vyriesUsek(vyslednyHad, index, queue)
                vyslednyHad = novyHad
                queue = novaQueue
            }

            if (queue.isEmpty()) {
                if (sediPom(vyslednyHad)) {
                    return Pair(true, null)
                } else {
                    return Pair(false, "Nesedí pomocný súčet")
                }
            }

            //tretikrat prejdem
            dlzka = queue.size
            for (i in 0 until dlzka) {
                val index = queue.removeAt(0)
                val (novyHad, novaQueue) = vyriesUsek(vyslednyHad, index, queue)
                vyslednyHad = novyHad
                queue = novaQueue
            }

            if (queue.isEmpty()) {
                if (sediPom(vyslednyHad)) {
                    return Pair(true, null)
                } else {
                    return Pair(false, "Nesedí pomocný súčet")
                }
            }

            if  (!backtrack(vyslednyHad)){
                return Pair(false, "Had sa nedá vyriešiť")
            } else {
                return Pair(true, null)
            }
        }

        private fun doplnNeposedy(vyslednyHad: Had, neposedy: List<Int>): Had {
            var novyHad = vyslednyHad.copy()
            for (i in neposedy.indices){
                if (i % 2 == 0){ //ide o sucet
                    novyHad.sucet[i/2] = neposedy[i]
                } else {
                    novyHad.operandy[i/2] = neposedy[i]
                }
            }
            novyHad.sucet[neposedy.size/2] = neposedy.last()
            return novyHad
        }

        private fun vytvorVsetkyKombinacie(neposedy: List<Int>): List<List<Int>> {
            val kombinacie = mutableListOf<List<Int>>()

            fun permutacie(aktualne: MutableList<Int>, zostavajuce: List<Int>) {
                if (zostavajuce.isEmpty()) {
                    kombinacie.add(aktualne.toList())
                    return
                }

                for (i in zostavajuce.indices) {
                    val novyAktualny = aktualne.toMutableList().apply { add(zostavajuce[i]) }
                    val novyZostavajuci = zostavajuce.toMutableList().apply { removeAt(i) }
                    permutacie(novyAktualny, novyZostavajuci)
                }
            }

            permutacie(mutableListOf(), neposedy)
            return kombinacie
        }

        private fun sediPom(vyslednyHad: Had): Boolean {
            if (vyslednyHad.pomocnySucet == null) return true
            Log.d("Had", vyslednyHad.toString())
            val sucet = vyslednyHad.pomocnySucet!!.second
            val prvy = vyslednyHad.sucet[(vyslednyHad.pomocnySucet!!.first.first)/3]!!
            val druhy = vyslednyHad.sucet[(vyslednyHad.pomocnySucet!!.first.second)/3]!!
            return prvy + druhy == sucet
        }

        private fun backtrack(vyslednyHad: Had): Boolean {
            var hadCopy = vyslednyHad.copy()

            for (i in vyslednyHad.sucet.indices) {
                if (vyslednyHad.sucet[i] == null) {
                    val rozsah = if (i < vyslednyHad.sucet.size - 1 &&
                        (vyslednyHad.operatory[i] == Operator.REVERSE ||
                                vyslednyHad.operatory[i] == Operator.DIVIDE ||
                                vyslednyHad.operatory[i] == Operator.SUBTRACT))
                        (99 downTo 0) else (0..99)

                    for (j in rozsah) {
                        hadCopy.sucet[i] = j


                        try {
                            if (isSolvable(hadCopy).first) {
                                return true
                            }
                        } catch (e: HadException) {

                        }
                    }
                }
            }
            return false
        }

        private fun vyriesUsek(vyslednyHad: Had, i: Int, queue: MutableList<Int> ) : Pair<Had, MutableList<Int>> {
            var vyslednyHad1 = vyslednyHad
            if (vsetkyVyplnene(vyslednyHad1, i)) {
                if (!kontrolaUseku(vyslednyHad1, i)) {
                    throw InvalidValueException("Had sa nedá vyriešiť")
                }

            } else if (praveDveVyplnene(vyslednyHad1, i)) {
                vyslednyHad1 = doplnHada(vyslednyHad1, i)

            } else if (chybaLenOperator(vyslednyHad1, i)) {
                vyslednyHad1 = doplnOperator(vyslednyHad1, i)

            } else if (chybaLenOperand(vyslednyHad1, i)) {
                vyslednyHad1 = doplnOperand(vyslednyHad1, i)

            } else {
                queue.add(i)
            }


            return Pair(vyslednyHad1, queue)
        }

        private fun doplnOperand(vyslednyHad: Had, i: Int): Had {
            var hadCopy = vyslednyHad.copy()

            val sucet1 = hadCopy.sucet[i]!!
            val sucet2 = hadCopy.sucet[i+1]!!
            val operator = hadCopy.operatory[i]!!
            if (operator == Operator.ADD && sucet1 <= sucet2){
                hadCopy.operandy[i] = sucet2 - sucet1
            } else if (operator == Operator.SUBTRACT && sucet1 >= sucet2){
                hadCopy.operandy[i] = sucet1 - sucet2
            } else if (operator == Operator.MULTIPLY && jeDelitelne(sucet2, sucet1)){
                if (sucet1 == 0){
                    if (sucet2 == 0) {
                        hadCopy.operandy[i] = 0
                    } else {
                        throw InvalidValueException("Had sa nedá vyriešiť")
                    }
                } else {
                    hadCopy.operandy[i] = sucet2 / sucet1
                }
            } else if (operator == Operator.DIVIDE && jeDelitelne(sucet1, sucet2)){
                if (sucet2 == 0){
                    if (sucet1 == 0) {
                        hadCopy.operandy[i] = 0
                    } else {
                        throw InvalidValueException("Had sa nedá vyriešiť")
                    }
                } else {
                    hadCopy.operandy[i] = sucet1 / sucet2
                }
            } else {
                throw InvalidValueException("Had sa nedá vyriešiť")
            }
            return hadCopy
        }

        private fun jeDelitelne(sucet2: Int, sucet1: Int): Boolean {
            if (sucet1 == 0) return sucet2 == 0
            return sucet2 % sucet1 == 0
        }

        private fun chybaLenOperand(vyslednyHad: Had, i: Int): Boolean {
            return vyslednyHad.sucet[i] != null && vyslednyHad.sucet[i+1] != null && vyslednyHad.operatory[i] != null && vyslednyHad.operatory[i] != Operator.REVERSE && vyslednyHad.operandy[i] == null
        }

        private fun doplnOperator(had: Had, i: Int): Had {
            var hadCopy = had.copy()

            val sucet1 = had.sucet[i]!!
            val sucet2 = had.sucet[i+1]!!
            val operand = had.operandy[i]!!
            val operator = had.operatory[i]

            if (operator == null){
                if (sucet1 <= sucet2){
                    if (sucet2 - sucet1 == operand){
                        hadCopy.operatory[i] = Operator.ADD
                    } else if (sucet1*operand == sucet2){
                        hadCopy.operatory[i] = Operator.MULTIPLY
                    } else {
                        throw InvalidValueException("Had sa nedá vyriešiť")
                    }
                } else if (operand == 0 && sucet2 == 0){
                    hadCopy.operatory[i] = Operator.MULTIPLY
                } else {
                    throw InvalidValueException("Had sa nedá vyriešiť")
                }

            } else if (operator == Operator.REVERSE){
                if (sucet1 >= sucet2){
                    if (sucet1 - sucet2 == operand){
                        hadCopy.operatory[i] = Operator.SUBTRACT
                    } else if (sucet2*operand == sucet1){
                        hadCopy.operatory[i] = Operator.DIVIDE
                    } else {
                        throw InvalidValueException("Had sa nedá vyriešiť")
                    }
                } else if (operand == 0 && sucet1 == 0){
                    hadCopy.operatory[i] = Operator.DIVIDE
                } else {
                    throw InvalidValueException("Had sa nedá vyriešiť")
                }
            } else {
                throw InvalidValueException("Had sa nedá vyriešiť")
            }

            return hadCopy
        }

        private fun chybaLenOperator(had: Had, i: Int): Boolean {
            return had.sucet[i] != null && had.sucet[i+1] != null && had.operandy[i]!= null && (had.operatory[i] == null || had.operatory[i] == Operator.REVERSE)
        }

        private fun doplnHada(had: Had, i: Int): Had {
            val hadCopy = had.copy()
            if (hadCopy.sucet[i] == null){
                hadCopy.sucet[i] = vratVysledokSucet1(had.operatory[i]!!, had.operandy[i]!!, had.sucet[i+1]!!)

            } else if (hadCopy.sucet[i+1] == null){
                hadCopy.sucet[i+1] = vratVysledokSucet2(had.sucet[i]!!, had.operatory[i]!!, had.operandy[i]!!)

            } else {
                val dvojica = vratOperatorOperand(had.sucet[i]!!, had.sucet[i+1]!!, had.operatory[i])
                hadCopy.operatory[i] = dvojica.first
                hadCopy.operandy[i] = dvojica.second
            }

            return hadCopy
        }

        private fun vratOperatorOperand(sucet1: Int, sucet2: Int, operator: Operator?): Pair<Operator, Int> {
            if (operator == null && sucet1<=sucet2){
                return Pair(Operator.ADD, sucet2-sucet1)
            } else if (operator == Operator.REVERSE && sucet1>=sucet2) {
                return Pair(Operator.SUBTRACT, sucet1 - sucet2)
            }
            throw InvalidValueException("Had sa nedá vyriešiť")
        }

        private fun vratVysledokSucet2(sucet: Int, operator: Operator, operand:  Int): Int? {
            if (operand == 0 && operator == Operator.DIVIDE && sucet != 0){
                throw InvalidValueException("Had sa nedá vyriešiť")
            } else if (operand == 0 && operator == Operator.DIVIDE){
                return 0
            }

            val result = when (operator) {
                Operator.ADD -> sucet + operand
                Operator.SUBTRACT -> sucet - operand
                Operator.MULTIPLY -> sucet * operand
                Operator.DIVIDE -> sucet / operand
                else -> null
            }

            result?.let {
                if (isValidResult(it.toFloat())) {
                    return it
                }
            }


            return result
        }

        private fun vratVysledokSucet1(operator: Operator, operand: Int, sucet: Int): Int? {


            if (operand == 0 && operator == Operator.MULTIPLY && sucet != 0){
                throw InvalidValueException("Had sa nedá vyriešiť")
            } else if (operand == 0 && operator == Operator.MULTIPLY){
                return 0
            }

            val result = when (operator) {
                Operator.ADD -> sucet - operand
                Operator.SUBTRACT -> sucet + operand
                Operator.MULTIPLY -> sucet / operand
                Operator.DIVIDE -> sucet * operand
                else -> null
            }

            result?.let {
                if (isValidResult(it.toFloat())) {
                    return it
                }
            }


            return result
        }

        private fun praveDveVyplnene(had: Had, i: Int): Boolean {
            return (had.sucet[i] != null && had.sucet[i+1] != null && (had.operatory[i] == null || had.operatory[i] == Operator.REVERSE) && had.operandy[i] == null ||
                    had.sucet[i] != null && had.sucet[i+1] == null && had.operatory[i] != null && had.operatory[i] != Operator.REVERSE && had.operandy[i] != null ||
                    had.sucet[i] == null && had.sucet[i+1] != null && had.operatory[i] != null && had.operatory[i] != Operator.REVERSE && had.operandy[i] != null)
        }

        private fun kontrolaUseku(had: Had, i: Int): Boolean {

            return when (had.operatory[i]) {
                Operator.ADD -> had.sucet[i] == had.sucet[i + 1]!! - had.operandy[i]!!
                Operator.SUBTRACT -> had.sucet[i] == had.sucet[i + 1]!! + had.operandy[i]!!
                Operator.MULTIPLY -> had.sucet[i+1] == had.sucet[i]!! * had.operandy[i]!!
                Operator.DIVIDE -> had.sucet[i] == had.sucet[i + 1]!! * had.operandy[i]!!
                else -> false
            }
        }

        private fun vsetkyVyplnene(had: Had, i: Int): Boolean {
            return had.sucet[i] != null && had.operatory[i] != null && had.operatory[i] != Operator.REVERSE && had.operandy[i] != null && had.sucet[i+1] != null
        }

        private fun jeVyplneny(had: Had): Boolean {
            for (i in 0 until had.sucet.size - 1) {
                if (had.sucet[i] == null || had.operatory[i] == null || had.operandy[i] == null || had.operatory[i] == Operator.REVERSE) {
                    return false
                }
            }
            if (had.sucet.last() == null) {
                return false
            }
            return true
        }

        private fun isValidResult(result: Float) : Boolean{
            if (result < 0 || result != result.toInt().toFloat()){
                throw InvalidValueException("Had sa nedá vyriešiť")
            } else if (result > 99){
                throw InvalidValueException("Had obsahuje príliš veľké čísla")
            }
            return true
        }

    }

}