package com.example.hady.logic

open class HadException(message: String) : Exception(message)

class InvalidValueException(message: String) : HadException(message)