import android.util.Log
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.AbsoluteCutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.TextStyle
import androidx.lifecycle.ViewModel
import com.example.hady.logic.Had
import com.example.hady.logic.Operator
import com.example.hady.R
import com.example.hady.logic.HadViewModel
import com.example.hady.ui.theme.*
import com.example.hady.ui.CalculatorScreen2


//vykreslim zadaneho hada s buttonmi a zadanymi hodnotami s Text

@Composable
fun HadUI(had: Had, hadCopy: Had, onColorSelected: (Color, Int) -> Unit, viewModel: HadViewModel) {
    BoxWithConstraints {
        val configuration = LocalConfiguration.current
        val isLandscape =
            configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE

        val screenWidth = maxWidth.value

        val scalingFactor = if (!isLandscape) screenWidth/400f else  screenWidth/800f


        val buttonSize = (50 * scalingFactor).dp
        val operandWidth = (60 * scalingFactor).dp
        val smallButtonHeight = (30 * scalingFactor).dp

        val arrowWidth = (50 * scalingFactor).dp
        val arrowHeadSize = 30 * scalingFactor

        val textSize = (30 * scalingFactor).sp
        val operandTextSize = (15 * scalingFactor).sp
        val operatorTextSize = (14 * scalingFactor).sp

        val pastelColors =  mutableListOf(
            PastelBlue, PastelOrange, PastelPink, PastelGreen, PastelYellow,
            PastelPurple, PastelRed, PastelTeal, PastelBeige, PastelMint
        )

        val focusedIndex = remember { mutableStateOf(0) }


        val fraction = if (!isLandscape) 0.44f else 0.35f

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(fraction)
                .padding(WindowInsets.statusBars.asPaddingValues())
        ) {

            Column(
                modifier = Modifier
                    .fillMaxSize(),
                verticalArrangement = Arrangement.Bottom,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(0.dp)
                ) {
                    for (i in had.sucet.indices) {

                        val sumColor = if (hadCopy.sucet[i] != null) {
                            Color.White
                        } else {
                            pastelColors[i * 3 % pastelColors.size]
                        }

                        Box(
                            modifier = Modifier
                                .size(buttonSize)
                                .padding(0.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .border(1.dp, Color.Black, RoundedCornerShape(36.dp))
                        ) {
                            Button(
                                onClick = {
                                    if (hadCopy.sucet[i] == null) {
                                        if (focusedIndex.value != i * 3 && had.neposedy == null) {
                                            had.sucet[i] = null
                                        }
                                        if (had.neposedy != null){
                                            viewModel.vymazNeposeda(i*3)
                                        }
                                        onColorSelected(sumColor, i * 3)
                                        focusedIndex.value = i * 3
                                    }
                                },
                                modifier = Modifier.fillMaxSize(),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = sumColor
                                )
                            ) {}

                            Text(
                                text = had.sucet[i]?.toString() ?: "",
                                style = TextStyle(
                                    fontSize = textSize,
                                    color = Color.Black,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center
                                ),
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(
                                        start = 6.dp,
                                        top = 8.dp,
                                        end = 6.dp,
                                        bottom = 8.dp
                                    )
                            )

                        }

                        if (i < had.operatory.size) {

                            val operator = had.getOperator(i)
                            val operatorCopy = hadCopy.getOperator(i)

                            Box(
                                modifier = Modifier
                                    .width(arrowWidth)
                                    .height(buttonSize - 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                val isReverseArrow =
                                    operatorCopy == Operator.SUBTRACT || operatorCopy == Operator.DIVIDE || operatorCopy == Operator.REVERSE

                                Canvas(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .fillMaxWidth()
                                ) {
                                    val centerY = size.height / 2
                                    val startX = if (isReverseArrow) size.width else 0f
                                    val endX = if (isReverseArrow) 0f else size.width
                                    val lineThickness = 8f

                                    drawLine(
                                        color = Color.Black,
                                        start = androidx.compose.ui.geometry.Offset(
                                            startX,
                                            centerY
                                        ),
                                        end = androidx.compose.ui.geometry.Offset(
                                            endX,
                                            centerY
                                        ),
                                        strokeWidth = lineThickness
                                    )

                                    val arrowTipX = endX
                                    val arrowTipY = centerY
                                    val arrowBaseY1 = centerY - arrowHeadSize / 2
                                    val arrowBaseY2 = centerY + arrowHeadSize / 2
                                    val arrowBaseX =
                                        endX - (if (isReverseArrow) -arrowHeadSize else arrowHeadSize)

                                    drawLine(
                                        color = Color.Black,
                                        start = androidx.compose.ui.geometry.Offset(
                                            arrowTipX,
                                            arrowTipY
                                        ),
                                        end = androidx.compose.ui.geometry.Offset(
                                            arrowBaseX,
                                            arrowBaseY1
                                        ),
                                        strokeWidth = lineThickness
                                    )

                                    drawLine(
                                        color = Color.Black,
                                        start = androidx.compose.ui.geometry.Offset(
                                            arrowTipX,
                                            arrowTipY
                                        ),
                                        end = androidx.compose.ui.geometry.Offset(
                                            arrowBaseX,
                                            arrowBaseY2
                                        ),
                                        strokeWidth = lineThickness
                                    )
                                }
                                Column(
                                    modifier = Modifier.offset(y = (-buttonSize / 2)),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Row(
                                        modifier = Modifier.padding(vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        val operatorColor =
                                            if (operatorCopy != null && operatorCopy!= Operator.REVERSE) Color.White else pastelColors[(i * 3 + 1) % pastelColors.size]

                                        var textik = ""
                                        if (operator == Operator.ADD || operator == Operator.SUBTRACT) {
                                            textik = "+"
                                        } else if (operator == Operator.MULTIPLY || operator == Operator.DIVIDE) {
                                            textik = "*"
                                        }

                                        Box(
                                            modifier = Modifier
                                                .size(smallButtonHeight - 14.dp)
                                                .padding(0.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                                .border(1.dp, Color.Black, RoundedCornerShape(14.dp))
                                        ) {

                                            Button(
                                                onClick = {
                                                    if (operatorCopy == null || operatorCopy == Operator.REVERSE) {
                                                        if (focusedIndex.value != i * 3 + 1 && had.neposedy == null) {
                                                            if ( had.operatory[i] == Operator.DIVIDE ||  had.operatory[i] == Operator.SUBTRACT || had.operatory[i] == Operator.REVERSE) {
                                                                had.operatory[i] = Operator.REVERSE
                                                            } else {
                                                                had.operatory[i] = null
                                                            }
                                                        }
                                                        onColorSelected(
                                                            operatorColor,
                                                            i * 3 + 1
                                                        )
                                                        focusedIndex.value = i * 3 + 1
                                                    }
                                                },
                                                modifier = Modifier
                                                    .size(smallButtonHeight - 14.dp),
                                                colors = ButtonDefaults.buttonColors(
                                                    containerColor = operatorColor
                                                )
                                            ) { }

                                            Text(
                                                text = textik,
                                                style = TextStyle(
                                                    fontSize = operatorTextSize,
                                                    color = Color.Black,
                                                    fontWeight = FontWeight.Bold,
                                                    textAlign = TextAlign.Center
                                                ),
                                                modifier = Modifier
                                                    .fillMaxSize()
                                                    .padding(
                                                        start = 0.dp)
                                            )

                                        }

                                        val operand = had.getOperand(i)
                                        val operandCopy = hadCopy.getOperand(i)


                                        val operandColor =
                                            if (operandCopy != null) Color.White else pastelColors[(i * 3 + 2) % pastelColors.size]

                                        Box(
                                            modifier = Modifier
                                                .size(smallButtonHeight)
                                                .padding(0.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                                .border(1.dp, Color.Black, RoundedCornerShape(30.dp))
                                        ) {
                                            Button(
                                                onClick = {
                                                    if (operandCopy == null) {
                                                        if (focusedIndex.value != i * 3 + 2 && had.neposedy == null) {
                                                            had.operandy[i] = null
                                                        }
                                                        if (had.neposedy != null){
                                                            viewModel.vymazNeposeda(i*3 + 2)
                                                        }
                                                        onColorSelected(
                                                            operandColor,
                                                            i * 3 + 2
                                                        )
                                                        focusedIndex.value = i * 3 + 2
                                                    }
                                                },
                                                modifier = Modifier
                                                    .width(operandWidth)
                                                    .height(smallButtonHeight)
                                                    .clip(AbsoluteCutCornerShape(0.dp)),
                                                colors = ButtonDefaults.buttonColors(
                                                    containerColor = operandColor
                                                )
                                            ) { }

                                            Text(
                                                text = operand?.toString() ?: "",
                                                style = TextStyle(
                                                    fontSize = operandTextSize,
                                                    color = Color.Black,
                                                    fontWeight = FontWeight.Bold,
                                                    textAlign = TextAlign.Center
                                                ),
                                                modifier = Modifier
                                                    .fillMaxSize()
                                                    .padding(
                                                        start = 0.dp,
                                                        top = 5.dp,
                                                        end = 0.dp,
                                                        bottom = 3.dp
                                                    )
                                            )

                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}