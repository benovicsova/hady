package com.example.hady.logic

import androidx.lifecycle.viewmodel.compose.viewModel

object Generator {

    var counts = mutableListOf(0, 0, 0, 0, 0)

    //generovanie vseobecneho vyplneneho hada danej dlzky s danymi podmienkami
    fun vygenerujHada(dlzka: Int, reverse: Boolean, multiply: Boolean, add : Boolean, range: Int): Had {
        val had = Had()
        had.inicializujHad(dlzka)

        var aktSucet : Int
        if (multiply) {
            aktSucet = (1..9).random()
        } else {
            aktSucet = (1..range).random()
        }
        had.setSucet(0, aktSucet)

        for (i in 0 until dlzka - 1) {
            var operator: Operator

            if (reverse){
                if (!add){
                    if (aktSucet <= 10) {
                        operator = Operator.MULTIPLY
                    } else {
                        operator = Operator.DIVIDE
                    }
                } else if (multiply && aktSucet < 10) {
                    operator = when ((0..3).random()) {
                        0 -> Operator.ADD
                        1 -> Operator.SUBTRACT
                        2 -> Operator.MULTIPLY
                        3 -> Operator.DIVIDE
                        else -> Operator.ADD
                    }
                } else {
                    operator = when ((0..1).random()) {
                        0 -> Operator.ADD
                        1 -> Operator.SUBTRACT
                        else -> {Operator.ADD}
                    }
                }
            } else {
                if (!add){
                    if (aktSucet <= 10) {
                        operator = Operator.MULTIPLY
                    } else {
                        operator = Operator.DIVIDE
                    }
                } else {
                    operator = Operator.ADD
                }
            }

            val operand = when (operator) {
                Operator.MULTIPLY -> (1..9).random()
                Operator.DIVIDE -> generateValidDivisionOperand(aktSucet)
                Operator.SUBTRACT -> {
                    if (aktSucet < 5) {
                        operator = Operator.ADD
                        (1..range).random()
                    } else {
                        (1..aktSucet-1).random()
                    }
                }
                else -> (1..range).random()
            }

            aktSucet = when (operator) {
                Operator.ADD -> aktSucet + operand
                Operator.SUBTRACT -> aktSucet - operand
                Operator.MULTIPLY -> aktSucet * operand
                Operator.DIVIDE -> aktSucet / operand
                else -> {aktSucet + operand}
            }

            had.setOperator(i, operator)
            had.setOperand(i, operand)
            had.setSucet(i + 1, aktSucet)
        }

        return had
    }

    private fun generateValidDivisionOperand(dividend: Int): Int {
        val validDivisors = (1..9).filter { it != 0 && dividend % it == 0 && dividend / it <= 9 }
        return if (validDivisors.isNotEmpty()) validDivisors.random() else 1
    }



    fun generujLevel1(): List<Had> {
        val hady = mutableListOf<Had>()
        repeat(2) { hady.add(generujU1L1()) }
        repeat(2) { hady.add(generujU2L1()) }
        repeat(2) { hady.add(generujU3L1()) }
        repeat(4) { hady.add(generujU4L1()) }
        counts[0] = hady.size
        return hady
    }

    private fun generujU1L1(): Had {
        val had = vygenerujHada(2, false, false, true, 10)
        when ((0..1).random()) {
            0 -> had.setSucet(1, null)
            1 -> had.setOperand(0, null)
        }
        return had
    }

    private fun generujU2L1(): Had {
        val had = vygenerujHada(3, false, false, true, 10)
        for (i in 1 until 3) {
            had.setSucet(i, null)
        }
        return had
    }

    private fun generujU3L1(): Had {
        val dlzka = (3..4).random()
        val had = vygenerujHada(dlzka, true, false, true, 15)
        val nahodne = (0 until dlzka).random()
        for (i in 0 until dlzka) {
            if (i != nahodne) {
                had.setSucet(i, null)
            }
        }
        return had
    }

    fun generujU4L1(): Had {
        val dlzka = (3..4).random()
        val had = vygenerujHada(dlzka, true, false, true, 20)


        for (i in 0 until dlzka-1) {
                if ((0..1).random() == 0 && had.getSucet(i) != null) {
                    if (had.getOperator(i) == Operator.ADD) {
                        had.setOperator(i, null)
                    } else {
                        had.setOperator(i, Operator.REVERSE)
                    }
                    had.setOperand(i, null)
                } else {
                    had.setSucet(i + 1, null)
                }

        }

        var vyplnene = false

        for (i in 1 until dlzka) {
            if (had.getSucet(i) != null)  {
                vyplnene = true
            }
        }

        if (vyplnene && had.getOperand(0) != null) {
            had.setSucet(0, null)
        }


        return had
    }



    fun generujLevel2(): List<Had> {
        val hady = mutableListOf<Had>()
        repeat(2) { hady.add(generujU1L2()) }
        repeat(2) { hady.add(generujU2L2()) }
        repeat(2) { hady.add(generujU3L2()) }
        repeat(4) { hady.add(generujU4L2()) }
        counts[1] = hady.size
        return hady
    }

    private fun generujU1L2(): Had {
        val had = vygenerujHada(2, false, true, false, 10)
        when ((0..1).random()) {
            0 -> had.setSucet(1, null)
            1 -> had.setOperand(0, null)
        }
        return had
    }

    private fun generujU2L2(): Had {
        val had = vygenerujHada(3, false, true, false, 10)
        for (i in 1 until 3) {
            had.setSucet(i, null)
        }
        return had
    }

    private fun generujU3L2(): Had {
        val dlzka = (3..4).random()
        val had = vygenerujHada(dlzka, true, true, false, 15)
        val nahodne = (0 until dlzka).random()
        for (i in 0 until dlzka) {
            if (i != nahodne) {
                had.setSucet(i, null)
            }
        }
        return had
    }

    fun generujU4L2(): Had {
        val had = vygenerujHada(4, true, true, false, 20)

        val rnd = (-5 until 0).random()
        for (i in 0 until 3) {
            if (i != rnd) {
                if ((0..1).random() == 0) {
                    if (had.getOperator(i) == Operator.ADD || had.getOperator(i) == Operator.MULTIPLY) {
                        had.setOperator(i, null)
                    } else {
                        had.setOperator(i, Operator.REVERSE)
                    }
                    had.setOperand(i, null)
                } else {
                    had.setSucet(i + 1, null)
                }
            }
        }

        var vyplnene = false

        for (i in 1 until 4) {
            if (had.getSucet(i) != null)  {
                vyplnene = true
            }
        }

        if (vyplnene && had.getOperand(0) != null && had.getSucet(1) != null) {
            had.setSucet(0, null)
        }

        return had
    }

    fun generujLevel3(): List<Had> {
        val hady = mutableListOf<Had>()
        repeat(3) {hady.add(generujU1L3())}
        repeat(3) {hady.add(generujU2L3())}
        repeat(4) {hady.add(generujU3L3())}
        counts[2] = hady.size
        return hady
    }

    fun generujU1L3(): Had {
        val had = vygenerujHada(2, true, false, true, 10)
        had.setSucet(0, null)
        had.setSucet(1, null)
        val operand = had.getOperand(0)
        if (operand != null) {
            val moznostiSucet = if (operand % 2 == 0) {
                (operand..20 step 2).toList()
            } else {
                (operand..19 step 2).toList()
            }
            val sucet = moznostiSucet.random()
            had.nastavPomocnySucet(0, 3, sucet)
        }
        return had
    }

    fun generujU2L3(): Had {
        val had = vygenerujHada(3, true, false, true, 10)
        val rnd = (0 until 2).random()
        val sucet = had.getSucet(rnd+1)!! + had.getSucet(rnd)!!
        had.nastavPomocnySucet(rnd*3, (rnd+1)*3, sucet )
        for (i in 0 until 3) {
            had.setSucet(i, null)
        }
        return had
    }

    fun generujU3L3(): Had {
        val dlzka = (3..4).random()
        val had = vygenerujHada(dlzka, true, false, true, 20)
        val rnd = (0 until dlzka-1).random()
        val sucet = had.getSucet(rnd+1)!! + had.getSucet(rnd)!!
        had.nastavPomocnySucet(rnd*3, (rnd+1)*3, sucet )
        had.setSucet(rnd, null)
        had.setSucet(rnd+1, null)
        for (i in 0 until dlzka-1) {
            if (i!=rnd){
                if ((0..1).random() == 0) {
                    had.setSucet(i + 1, null)
                } else {
                    if (had.getOperator(i) == Operator.ADD) {
                        had.setOperator(i, null)
                    } else {
                        had.setOperator(i, Operator.REVERSE)
                    }
                    had.setOperand(i, null)
                }
            }
        }
        if (had.getOperand(0) != null) {
            had.setSucet(0, null)
        }
        return had
    }

    fun generujLevel4(): List<Had> {
        val hady = mutableListOf<Had>()
        repeat(2) {hady.add(generujU1L4())}
        repeat(3) {hady.add(generujU2L4())}
        repeat(5) {hady.add(generujU3L4())}
        counts[3] = hady.size
        return hady
    }


    fun generujU1L4(): Had {
        val had = vygenerujHada(2, true, false, true, 10)
        var neposedy = mutableListOf<Int>()
        neposedy.add(had.getSucet(0)!!)
        neposedy.add(had.getSucet(1)!!)
        neposedy.add(had.getOperand(0)!!)
        had.nastavNeposedy(neposedy)
        had.setSucet(0, null)
        had.setSucet(1, null)
        had.setOperand(0, null)
        return had
    }

    private fun generujU2L4(): Had {
        val had = vygenerujHada(3, false, false, true, 15)
        var neposedy = mutableListOf<Int>()
        for (i in 0 until 2) {
            neposedy.add(had.getSucet(i)!!)
            had.setSucet(i, null)
            neposedy.add(had.getOperand(i)!!)
            had.setOperand(i, null)
        }
        neposedy.add(had.getSucet(2)!!)
        had.setSucet(2, null)
        had.nastavNeposedy(neposedy)
        return had
    }

    fun generujU3L4(): Had {
        val dlzka = (3..4).random()
        val had = vygenerujHada(dlzka, true, true, true, 15)
        var neposedy = mutableListOf<Int>()
        for (i in 0 until dlzka-1) {
            neposedy.add(had.getSucet(i)!!)
            had.setSucet(i, null)
            neposedy.add(had.getOperand(i)!!)
            had.setOperand(i, null)
        }
        neposedy.add(had.getSucet(dlzka-1)!!)
        had.setSucet(dlzka-1, null)
        had.nastavNeposedy(neposedy)
        return had
    }

    fun generujLevel5(): List<Had> {
        val hady = mutableListOf<Had>()
        repeat(4){
            val rnd = (0..3).random()
            if (rnd == 0) {
                hady.add(generujU1L1())
            } else if (rnd == 1) {
                hady.add(generujU1L2())
            } else if (rnd == 2) {
                hady.add(generujU1L3())
            } else {
                hady.add(generujU1L4())
            }
        }
        repeat(4){
            val rnd = (0..3).random()
            if (rnd == 0) {
                hady.add(generujU2L1())
            } else if (rnd == 1) {
                hady.add(generujU2L2())
            } else if (rnd == 2) {
                hady.add(generujU2L3())
            } else {
                hady.add(generujU2L4())
            }
        }
        repeat(3){
            val rnd = (0..3).random()
            if (rnd == 0) {
                hady.add(generujU3L1())
            } else if (rnd == 1) {
                hady.add(generujU3L2())
            } else if (rnd == 2) {
                hady.add(generujU2L3())
            } else {
                hady.add(generujU2L4())
            }
        }
        repeat(4){
            val rnd = (0..3).random()
            if (rnd == 0) {
                hady.add(generujU4L1())
            } else if (rnd == 1) {
                hady.add(generujU4L2())
            } else if (rnd == 2) {
                hady.add(generujU3L3())
            } else {
                hady.add(generujU3L4())
            }
        }
        counts[4] = hady.size
        return hady
    }

    fun generujU4L5(): Had {
        val rnd = (0..3).random()
        if (rnd == 0) {
            return generujU4L1()
        } else if (rnd == 1) {
            return generujU4L2()
        } else if (rnd == 2) {
            return generujU3L3()
        } else {
            return generujU3L4()
        }
    }

}
