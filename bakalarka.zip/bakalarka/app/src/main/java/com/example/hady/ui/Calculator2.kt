package com.example.hady.ui

import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.hady.logic.Generator
import com.example.hady.logic.Had
import com.example.hady.logic.Operator
import com.example.hady.ui.theme.*
import com.example.hady.logic.HadViewModel

@Composable
fun CalculatorScreen2(
    had: Had,
    hadCopy: Had,
    selectedButtonIndex: Int,
    onSelectButton: (Int) -> Unit,
    onHadChange: (Had.() -> Unit) -> Unit,
    navController: NavController?,
    viewModel: HadViewModel
) {
    val configuration = LocalConfiguration.current
    val isLandscape =
        configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE

    val screenWidth = LocalConfiguration.current.screenWidthDp

    val scalingFactor = if (!isLandscape) screenWidth/400f else  screenWidth/800f

    val buttonSize = (50 * scalingFactor).dp

    val buttonSpacing: Dp = 8.dp
    val buttonsPerRow = 5
    val calculatorPadding: Dp = 16.dp
    val pastelColors = mutableListOf(
        PastelBlue, PastelOrange, PastelPink, PastelGreen, PastelYellow,
        PastelPurple, PastelRed, PastelTeal, PastelBeige, PastelMint
    )

    val calculatorColor = pastelColors[selectedButtonIndex % pastelColors.size]
    val buttonColor = darkenColor2(calculatorColor, 0.15f)
    val buttonEnterColor = darkenColor2(calculatorColor, 0.3f)

    val calculatorWidth = (buttonSize * buttonsPerRow) + (buttonSpacing * (buttonsPerRow - 1)) + calculatorPadding * 2

    var showDialog by remember { mutableStateOf(false) }
    var isValid by remember { mutableStateOf(true) }

    var showUnlockDialog by remember { mutableStateOf(false) }

    val availableNumbers = viewModel.availableNumbers

    val fullNumberList = viewModel.fullNumberList
    Log.d("Calculator", "fullNumberList: $fullNumberList")

    val removedNumbers = viewModel.removedNumbers

    LaunchedEffect(had.neposedy) {
        Log.d("Calculator", "nulujem")
        viewModel.removedNumbers.clear()
    }

    LaunchedEffect(viewModel.levelProgress.value[viewModel.currentLevel]) {
        if (viewModel.levelProgress.value[viewModel.currentLevel] >= 0.5f &&
            viewModel.currentLevel < 4 &&
            viewModel.unlockedLevels[viewModel.currentLevel + 1] != true
        ) {
            viewModel.unlockLevel(viewModel.currentLevel + 1)
            showUnlockDialog = true
        }
    }

    val numberRows = fullNumberList.chunked(5)


    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .offset(y = (-20).dp)
                .width(calculatorWidth)
                .border(1.dp, Color.Black, RoundedCornerShape(16.dp))
                .background(calculatorColor, RoundedCornerShape(16.dp))
                .padding(calculatorPadding)

        ){
            Row(horizontalArrangement = Arrangement.spacedBy(buttonSpacing), modifier = Modifier.fillMaxWidth()) {
                CalculatorButton2("⌫", buttonSize, buttonSize, buttonColor) {
                    onHadChange {
                        Log.d("Calculator", "r: $removedNumbers a: $availableNumbers")
                        when (selectedButtonIndex % 3) {
                            0 -> {
                                val currentNumber = sucet[selectedButtonIndex / 3]
                                if (currentNumber != null) {
                                    val removedIndex = removedNumbers.indexOfFirst { it.second == currentNumber }
                                    if (removedIndex != -1) {
                                        val restoredPair = removedNumbers.removeAt(removedIndex)
                                        availableNumbers.add(restoredPair)
                                        availableNumbers.sortBy { it.first }
                                    }
                                    sucet[selectedButtonIndex / 3] = null
                                }
                            }
                            2 -> {
                                val currentNumber = operandy[selectedButtonIndex / 3]
                                if (currentNumber != null) {
                                    val removedIndex = removedNumbers.indexOfFirst { it.second == currentNumber }
                                    if (removedIndex != -1) {
                                        val restoredPair = removedNumbers.removeAt(removedIndex)
                                        availableNumbers.add(restoredPair)
                                        availableNumbers.sortBy { it.first }
                                    }
                                    operandy[selectedButtonIndex / 3] = null
                                }
                            }
                        }
                    }
                }


                Spacer(modifier = Modifier.width(buttonSize * 2 + buttonSpacing))

                CalculatorButton2("✔", buttonSize * 2 + buttonSpacing, buttonSize, buttonEnterColor) {
                    val isCorrect = had.check()
                    isValid = isCorrect
                    showDialog = true
                }
            }

            Spacer(modifier = Modifier.height(buttonSpacing))

            for (row in numberRows) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(buttonSpacing),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    for (item in row) {
                        if (item != null) {
                            val (index, number) = item
                            val isAvailable = availableNumbers.any { it.first == index && it.second == number }

                            if (isAvailable) {
                                CalculatorButton2(number.toString(), buttonSize, buttonSize, buttonColor) {
                                    onHadChange {
                                        when (selectedButtonIndex % 3) {
                                            0 -> {
                                                if (sucet[selectedButtonIndex / 3] == null) {
                                                    sucet[selectedButtonIndex / 3] = number

                                                    val removeIndex = availableNumbers.indexOfFirst { it.first == index && it.second == number }
                                                    if (removeIndex != -1) {
                                                        removedNumbers.add(availableNumbers.removeAt(removeIndex))
                                                    }
                                                }
                                            }
                                            2 -> {
                                                if (operandy[selectedButtonIndex / 3] == null) {
                                                    operandy[selectedButtonIndex / 3] = number

                                                    val removeIndex = availableNumbers.indexOfFirst { it.first == index && it.second == number }
                                                    if (removeIndex != -1) {
                                                        removedNumbers.add(availableNumbers.removeAt(removeIndex))
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            } else {
                                Box(
                                    modifier = Modifier
                                        .size(buttonSize, buttonSize)
                                        .clip(RoundedCornerShape(8.dp))
                                )
                            }
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(buttonSize, buttonSize)
                                    .clip(RoundedCornerShape(8.dp))
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(buttonSpacing))
            }
        }

        if (showDialog) {
            if (viewModel.currentHadIndex.value == Generator.counts[viewModel.currentLevel]-1 && viewModel.currentLevel != 4 && isValid) {
                FinalResultDialog(
                    viewModel = viewModel,
                    progressColor = viewModel.levels[viewModel.currentLevel],
                    onDismiss = { showDialog = false },
                    onNext = {
                        viewModel.nextHad()
                        showDialog = false
                    },
                    onEdit = {
                        navController?.navigate("editor_screen")
                        viewModel.editorMode.value = 1
                        showDialog = false
                        viewModel.nextHad()
                    }
                )
            } else {
                ResultDialog(
                    isValid = isValid,
                    onDismiss = {
                        if (viewModel.editorMode.value == 1) {
                            if (isValid) {
                                viewModel.editorMode.value = 2
                                viewModel.had.value = had
                                viewModel.hadCopy.value = had.copy()
                                if (viewModel.currentLevel!=2) {
                                    viewModel.had.value.pomocnySucet = null
                                }

                                viewModel.updateSelectedButtonIndex()

                                navController?.navigate("main_screen") {
                                    popUpTo("main_screen") { inclusive = true }
                                }
                            }
                        } else if (viewModel.editorMode.value == 2) {
                            if (isValid) {
                                navController?.navigate("editor_screen") {
                                    popUpTo("editor_screen") { inclusive = true }
                                }
                                viewModel.editorMode.value = 1
                                val novyHad = Had().apply {
                                    inicializujHad(2)
                                    if (viewModel.currentLevel == 2) {
                                        nastavPomocnySucet(0, 3, null)
                                    }
                                }
                                viewModel.had.value = novyHad
                                viewModel.hadCopy.value = novyHad.copy()

                                viewModel.updateSelectedButtonIndex()
                            }
                        }
                        showDialog = false
                    },
                    viewModel = viewModel,
                    onRetry = {
                        showDialog = false
                    }
                )

            }
        }

        if (showUnlockDialog ) {
            UnlockLevelDialog(newLevel = viewModel.currentLevel + 1, color = viewModel.levels[viewModel.currentLevel+1]) {
                showUnlockDialog = false
            }
        }
    }
}

@Composable
fun CalculatorButton2(
    text: String,
    sizeW: Dp,
    sizeH: Dp,
    color: Color,
    onClick: () -> Unit
) {
    val configuration = LocalConfiguration.current
    val isLandscape =
        configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE

    val screenWidth = LocalConfiguration.current.screenWidthDp

    val scalingFactor = if (!isLandscape) screenWidth/400f else  screenWidth/800f

    val textSize = (30 * scalingFactor).sp

    Box(
        modifier = Modifier
            .size(sizeW, sizeH)
            .padding(0.dp)
            .clip(RoundedCornerShape(8.dp))
            .border(1.dp, Color.Black, RoundedCornerShape(sizeH))
    ) {
        Button(
            onClick = onClick,
            modifier = Modifier
                .width(sizeW)
                .height(sizeH)
                .clip(RoundedCornerShape(8.dp)),
            colors = ButtonDefaults.buttonColors(containerColor = color)
        ) {}

        Text(
            text = text,
            style = TextStyle(
                fontSize = textSize,
                fontWeight = FontWeight.Bold,
                color = Color.Black
            ),
            modifier = Modifier
                .align(Alignment.Center)
                .padding(0.dp),
            textAlign = TextAlign.Center
        )
    }
}


fun darkenColor2(color: Color, factor: Float): Color {
    val red = (color.red - factor).coerceIn(0f, 1f)
    val green = (color.green - factor).coerceIn(0f, 1f)
    val blue = (color.blue - factor).coerceIn(0f, 1f)
    return Color(red, green, blue)
}