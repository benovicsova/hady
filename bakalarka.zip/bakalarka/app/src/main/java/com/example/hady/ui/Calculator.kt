package com.example.hady.ui

import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.hady.logic.Generator
import com.example.hady.logic.Had
import com.example.hady.logic.Operator
import com.example.hady.ui.theme.*
import com.example.hady.logic.HadViewModel
import com.example.hady.logic.Solver

@Composable
fun CalculatorScreen(
    had: Had,
    hadCopy: Had,
    selectedButtonIndex: Int,
    onSelectButton: (Int) -> Unit,
    onHadChange: (Had.() -> Unit) -> Unit,
    navController: NavController?,
    viewModel: HadViewModel
) {
    val buttonSize: Dp = 55.dp
    val buttonSpacing: Dp = 8.dp
    val buttonsPerRow = 5
    val calculatorPadding: Dp = 16.dp
    val pastelColors =  mutableListOf(
        PastelBlue, PastelOrange, PastelPink, PastelGreen, PastelYellow,
        PastelPurple, PastelRed, PastelTeal, PastelBeige, PastelMint
    )

    var calculatorColor = Color.White

    if (selectedButtonIndex != -1){
        calculatorColor = pastelColors[selectedButtonIndex % pastelColors.size]
    }
    val buttonColor = darkenColor(calculatorColor, 0.15f)
    val buttonEnterColor = darkenColor(calculatorColor, 0.3f)

    val calculatorWidth = (buttonSize * buttonsPerRow) + (buttonSpacing * (buttonsPerRow - 1)) + calculatorPadding * 2

    var showDialog by remember { mutableStateOf(false) }
    var isValid by remember { mutableStateOf(true) }

    val progressList by remember { viewModel.levelProgress }

    var showUnlockDialog by remember { mutableStateOf(false) }

    LaunchedEffect(viewModel.selectedButtonIndex) {
        Log.d("CalculatorScreen", "Focus changed to button at index: ${viewModel.selectedButtonIndex.value}")
    }

    LaunchedEffect(viewModel.levelProgress.value[viewModel.currentLevel]) {
        if (viewModel.levelProgress.value[viewModel.currentLevel] >= 0.5f &&
            viewModel.currentLevel < 4 &&
            viewModel.unlockedLevels[viewModel.currentLevel + 1] != true
        ) {
            viewModel.unlockLevel(viewModel.currentLevel + 1)
            showUnlockDialog = true
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .offset(y = (-20).dp)
                .width(calculatorWidth)
                .border(1.dp, Color.Black, RoundedCornerShape(16.dp))
                .background(calculatorColor, RoundedCornerShape(16.dp))
                .padding(calculatorPadding)

        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(buttonSpacing), modifier = Modifier.fillMaxWidth()) {

                var dlzka = buttonSize
                if (viewModel.currentLevel==0) {
                    dlzka = buttonSize * 2 + buttonSpacing
                }

                CalculatorButton("⌫", dlzka, buttonSize, buttonColor) {
                    onHadChange {
                        if (selectedButtonIndex == -1) {
                            val current = had.pomocnySucet?.second?.toString() ?: ""
                            Log.d("Had", "Deleting from pomocnySucet: $current")
                            pomocnySucet = had.pomocnySucet?.copy(second = current.dropLast(1).toIntOrNull())
                        } else {
                            when (selectedButtonIndex % 3) {
                                0 -> {
                                    sucet[selectedButtonIndex / 3] =
                                        sucet[selectedButtonIndex / 3]?.toString()?.dropLast(1)
                                            ?.toIntOrNull()
                                }

                                1 -> operatory[selectedButtonIndex / 3] = null
                                2 -> {
                                    operandy[selectedButtonIndex / 3] =
                                        operandy[selectedButtonIndex / 3]?.toString()?.dropLast(1)
                                            ?.toIntOrNull()
                                }
                            }
                        }
                    }
                }

                CalculatorButton("+", buttonSize, buttonSize, buttonColor) {
                    onHadChange {
                        if (selectedButtonIndex % 3 == 1 && operatory[selectedButtonIndex / 3] == null ) {
                            setOperator(selectedButtonIndex / 3, Operator.ADD)
                        } else if (selectedButtonIndex % 3 == 1 && operatory[selectedButtonIndex / 3] == Operator.REVERSE) {
                            setOperator(selectedButtonIndex / 3, Operator.SUBTRACT)
                        }
                    }
                }

                if (viewModel.currentLevel!=0) {
                    CalculatorButton("*", buttonSize, buttonSize, buttonColor) {
                        onHadChange {
                            if (selectedButtonIndex % 3 == 1 && operatory[selectedButtonIndex / 3] == null) {
                                setOperator(selectedButtonIndex / 3, Operator.MULTIPLY)
                            } else if (selectedButtonIndex % 3 == 1 && operatory[selectedButtonIndex / 3] == Operator.REVERSE) {
                                setOperator(selectedButtonIndex / 3, Operator.DIVIDE)
                            }
                        }
                    }
                }

                CalculatorButton("✔", buttonSize * 2 + buttonSpacing, buttonSize, buttonEnterColor) {
                    if (viewModel.editorMode.value==1){
                        if (viewModel.currentLevel==3) {
                            var neposedky = mutableListOf<Int>()
                            try {
                                for (i in had.operandy.indices) {
                                    neposedky.add(had.sucet[i]!!)
                                    neposedky.add(had.operandy[i]!!)
                                }
                                neposedky.add(had.sucet[had.sucet.size - 1]!!)
                            } catch (e: NullPointerException) {
                                val isCorrect = false
                                viewModel.editorMessage.value = "Nie sú vyplnené všetky hodnoty"
                            }
                            had.neposedy = neposedky
                        }
                        val isCorrect =  Solver.isSolvable(viewModel.had.value).first
                        viewModel.editorMessage.value = Solver.isSolvable(viewModel.had.value).second.toString()
                        isValid = isCorrect
                        showDialog = true

                        if (viewModel.currentLevel==3) {
                            for (i in 0 until had.sucet.size-1) {
                                had.setSucet(i, null)
                                had.setOperand(i, null)
                            }
                            had.setSucet(had.sucet.size-1, null)
                        }

                        viewModel.updateSelectedButtonIndex()

                    } else {
                        val isCorrect = had.check()
                        viewModel.editorMessage.value = ""
                        isValid = isCorrect
                        showDialog = true
                    }
                }
            }

            Spacer(modifier = Modifier.height(buttonSpacing))

            val numberButtons = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")

            for (i in 0 until 2) {
                Row(horizontalArrangement = Arrangement.spacedBy(buttonSpacing), modifier = Modifier.fillMaxWidth()) {
                    for (j in 0 until 5) {
                        val index = i * 5 + j
                        if (index < numberButtons.size) {
                            val number = numberButtons[index]
                            CalculatorButton(number, buttonSize, buttonSize, buttonColor) {
                                onHadChange {
                                    if (selectedButtonIndex == -1) {
                                        val current = had.pomocnySucet?.second?.toString() ?: ""
                                        if (current.length < 2) {
                                            pomocnySucet = had.pomocnySucet?.copy(second = (current + number).toInt())
                                        }
                                    } else {
                                        when (selectedButtonIndex % 3) {
                                            0 -> {
                                                val current =
                                                    sucet[selectedButtonIndex / 3]?.toString() ?: ""
                                                if (current.length < 2) {
                                                    setSucet(
                                                        selectedButtonIndex / 3,
                                                        (current + number).toInt()
                                                    )
                                                }
                                            }

                                            2 -> {
                                                val current =
                                                    operandy[selectedButtonIndex / 3]?.toString()
                                                        ?: ""
                                                if (current.length < 2) {
                                                    setOperand(
                                                        selectedButtonIndex / 3,
                                                        (current + number).toInt()
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(buttonSpacing))
            }
        }

        if (showDialog) {
            if (viewModel.currentHadIndex.value == Generator.counts[viewModel.currentLevel]-1 && viewModel.currentLevel != 4) {
                FinalResultDialog(
                    viewModel = viewModel,
                    progressColor = viewModel.levels[viewModel.currentLevel],
                    onDismiss = { showDialog = false },
                    onNext = {
                        viewModel.nextHad()
                        showDialog = false
                    },
                    onEdit = {
                        navController?.navigate("editor_screen")
                        viewModel.editorMode.value = 1
                        showDialog = false
                        viewModel.nextHad()
                    }
                )
            } else {
                ResultDialog(
                    isValid = isValid,
                    onDismiss = {
                        if (viewModel.editorMode.value == 1) {
                            if (isValid) {
                                viewModel.editorMode.value = 2
                                viewModel.had.value = had
                                viewModel.hadCopy.value = had.copy()
                                if (viewModel.currentLevel!=2) {
                                    viewModel.had.value.pomocnySucet = null
                                }

                                viewModel.updateSelectedButtonIndex()

                                navController?.navigate("main_screen") {
                                    popUpTo("main_screen") { inclusive = true }
                                }
                            }
                        } else if (viewModel.editorMode.value == 2) {
                            if (isValid) {
                                navController?.navigate("editor_screen") {
                                    popUpTo("editor_screen") { inclusive = true }
                                }
                                viewModel.editorMode.value = 1
                                val novyHad = Had().apply {
                                    inicializujHad(2)
                                    if (viewModel.currentLevel == 2) {
                                        nastavPomocnySucet(0, 3, null)
                                    }
                                }
                                viewModel.had.value = novyHad
                                viewModel.hadCopy.value = novyHad.copy()

                                viewModel.updateSelectedButtonIndex()
                            }
                        }
                        showDialog = false
                    },
                    viewModel = viewModel,
                    onRetry = {
                        showDialog = false
                    }
                )

            }
        }

        if (showUnlockDialog ) {
            UnlockLevelDialog(newLevel = viewModel.currentLevel + 1, color = viewModel.levels[viewModel.currentLevel+1]) {
                showUnlockDialog = false
            }
        }
    }
}


@Composable
fun CalculatorButton(
    text: String,
    sizeW: Dp,
    sizeH: Dp,
    color: Color,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .width(sizeW)
            .height(sizeH)
            .border(1.dp, Color.Black, RoundedCornerShape(32.dp))
            .clip(RoundedCornerShape(8.dp)),
        colors = ButtonDefaults.buttonColors(containerColor = color)
    ) {
        Text(
            text = text,
            style = TextStyle(
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Black
            ),
            textAlign = TextAlign.Center
        )
    }
}

fun darkenColor(color: Color, factor: Float): Color {
    val red = (color.red - factor).coerceIn(0f, 1f)
    val green = (color.green - factor).coerceIn(0f, 1f)
    val blue = (color.blue - factor).coerceIn(0f, 1f)
    return Color(red, green, blue)
}