package com.example.hady.ui

import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.hady.logic.Had
import com.example.hady.logic.Operator
import com.example.hady.ui.theme.*
import com.example.hady.logic.HadViewModel

@Composable
fun CalculatorScreen(
    had: Had,
    hadCopy: Had,
    selectedButtonIndex: Int,
    onSelectButton: (Int) -> Unit,
    onHadChange: (Had.() -> Unit) -> Unit,
    navController: NavController?,
    viewModel: HadViewModel
) {
    val buttonSize: Dp = 55.dp
    val buttonSpacing: Dp = 8.dp
    val buttonsPerRow = 5
    val calculatorPadding: Dp = 16.dp
    val pastelColors =  mutableListOf(
        PastelBlue, PastelOrange, PastelPink, PastelGreen, PastelYellow,
        PastelPurple, PastelRed, PastelTeal, PastelBeige, PastelMint
    )

    val calculatorColor = pastelColors[selectedButtonIndex % pastelColors.size]
    val buttonColor = darkenColor(calculatorColor, 0.15f)
    val buttonEnterColor = darkenColor(calculatorColor, 0.3f)

    val calculatorWidth = (buttonSize * buttonsPerRow) + (buttonSpacing * (buttonsPerRow - 1)) + calculatorPadding * 2

    var showDialog by remember { mutableStateOf(false) }
    var isValid by remember { mutableStateOf(true) }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .offset(y = (-20).dp)
                .width(calculatorWidth)
                .background(calculatorColor, RoundedCornerShape(16.dp))
                .padding(calculatorPadding)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(buttonSpacing), modifier = Modifier.fillMaxWidth()) {
                CalculatorButton("⌫", buttonSize, buttonSize, buttonColor) {
                    onHadChange {
                        when (selectedButtonIndex % 3) {
                            0 -> {
                                sucet[selectedButtonIndex / 3] =
                                    sucet[selectedButtonIndex / 3]?.toString()?.dropLast(1)?.toIntOrNull()
                            }
                            1 -> operatory[selectedButtonIndex / 3] = null
                            2 -> {
                                operandy[selectedButtonIndex / 3] =
                                    operandy[selectedButtonIndex / 3]?.toString()?.dropLast(1)?.toIntOrNull()
                            }
                        }
                    }
                }
                CalculatorButton("+", buttonSize, buttonSize, buttonColor) {
                    onHadChange {
                        if (selectedButtonIndex % 3 == 1 && operatory[selectedButtonIndex / 3] == null ) {
                            setOperator(selectedButtonIndex / 3, Operator.ADD)
                        } else if (selectedButtonIndex % 3 == 1 && operatory[selectedButtonIndex / 3] == Operator.REVERSE) {
                            setOperator(selectedButtonIndex / 3, Operator.SUBTRACT)
                        }
                    }
                }
                CalculatorButton("*", buttonSize, buttonSize, buttonColor) {
                    onHadChange {
                        if (selectedButtonIndex % 3 == 1 && operatory[selectedButtonIndex / 3] == null) {
                            setOperator(selectedButtonIndex / 3, Operator.MULTIPLY)
                        } else if (selectedButtonIndex % 3 == 1 && operatory[selectedButtonIndex / 3] == Operator.REVERSE) {
                            setOperator(selectedButtonIndex / 3, Operator.DIVIDE)
                        }
                    }
                }
                CalculatorButton("✔", buttonSize * 2 + buttonSpacing, buttonSize, buttonEnterColor) {
                    val isCorrect = had.check()

                    isValid = isCorrect
                    showDialog = true
                }
            }

            Spacer(modifier = Modifier.height(buttonSpacing))

            val numberButtons = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")

            for (i in 0 until 2) {
                Row(horizontalArrangement = Arrangement.spacedBy(buttonSpacing), modifier = Modifier.fillMaxWidth()) {
                    for (j in 0 until 5) {
                        val index = i * 5 + j
                        if (index < numberButtons.size) {
                            val number = numberButtons[index]
                            CalculatorButton(number, buttonSize, buttonSize, buttonColor) {
                                onHadChange {
                                    when (selectedButtonIndex % 3) {
                                        0 -> {
                                            val current = sucet[selectedButtonIndex / 3]?.toString() ?: ""
                                            if (current.length < 2) {
                                                setSucet(selectedButtonIndex / 3, (current + number).toInt())
                                            }
                                        }
                                        2 -> {
                                            val current = operandy[selectedButtonIndex / 3]?.toString() ?: ""
                                            if (current.length < 2) {
                                                setOperand(selectedButtonIndex / 3, (current + number).toInt())
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(buttonSpacing))
            }
        }

        if (showDialog) {
            ResultDialog(
                isValid = isValid,
                onDismiss = { showDialog = false },
                viewModel = viewModel,
                onRetry = { showDialog = false }
            )
        }
    }
}


@Composable
fun CalculatorButton(
    text: String,
    sizeW: Dp,
    sizeH: Dp,
    color: Color,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .width(sizeW)
            .height(sizeH)
            .clip(RoundedCornerShape(8.dp)),
        colors = ButtonDefaults.buttonColors(containerColor = color)
    ) {
        Text(
            text = text,
            style = TextStyle(
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Black
            ),
            textAlign = TextAlign.Center
        )
    }
}

fun darkenColor(color: Color, factor: Float): Color {
    val red = (color.red - factor).coerceIn(0f, 1f)
    val green = (color.green - factor).coerceIn(0f, 1f)
    val blue = (color.blue - factor).coerceIn(0f, 1f)
    return Color(red, green, blue)
}