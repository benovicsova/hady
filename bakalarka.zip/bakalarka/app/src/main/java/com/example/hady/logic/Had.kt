package com.example.hady.logic

import android.util.Log
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import com.example.hady.ui.theme.*

enum class Operator(val operation: (Int, Int) -> Int?) {

    ADD({ a, b -> a + b }),
    SUBTRACT({ a, b -> a - b }),
    MULTIPLY({ a, b -> a * b }),
    DIVIDE({ a, b -> if (b != 0) a / b else null }),
    REVERSE({ _, _ -> null });

    companion object {
        fun toString(operator: Operator): String {
            return when (operator) {
                ADD -> "+"
                SUBTRACT -> "-"
                MULTIPLY -> "x"
                DIVIDE -> "/"
                REVERSE -> "r"
                else -> ""
            }
        }

        fun fromString(string: String): Operator {
            return when (string) {
                "+" -> ADD
                "-" -> SUBTRACT
                "x" -> MULTIPLY
                "/" -> DIVIDE
                "r" -> REVERSE
                else -> throw IllegalArgumentException("Neznámy operátor $string!")
            }
        }
    }
}

class Had{
    var operatory: MutableList<Operator?> = ArrayList()
    var operandy: MutableList<Int?> = ArrayList()
    var sucet: MutableList<Int?> = ArrayList()
    var buttonColors: MutableList<Color> = ArrayList() // Zoznam farieb pre tlačidlá
    val availableColors = mutableListOf(
        PastelBlue, PastelOrange, PastelPink, PastelGreen, PastelYellow,
        PastelPurple, PastelRed, PastelTeal, PastelBeige, PastelMint
    ) // Zoznam dostupných farieb

    var pomocnySucet by mutableStateOf<Pair<Pair<Int, Int>, Int?>?>(null)

    var neposedy by mutableStateOf<List<Int>?>(null)


    fun inicializujHad(velkost: Int) {
        sucet.add(null)
        buttonColors.add(assignUniqueColor())
        for (i in 1 until velkost) {
            operatory.add(null)
            operandy.add(null)
            sucet.add(null)
            buttonColors.add(assignUniqueColor())
        }
    }

    fun check(): Boolean {
        if (sucet[0] == null) return false
        var check = sucet[0]
        for (i in operatory.indices) {
            val operator = operatory[i] ?: return false
            Log.d("Had", "Checking operator $operator")
            val operand = operandy[i] ?: return false
            Log.d("Had", "Checking operand $operand")
            val result = sucet[i + 1] ?: return false
            Log.d("Had", "Checking result $result")
            if (operator.operation(check!!, operand) != result) return false
            Log.d("Had", "Checking passed")
            check = result
        }
        if (pomocnySucet!=null){
            val prvy = getSucet((pomocnySucet!!.first.first)/3)!!
            val druhy = getSucet((pomocnySucet!!.first.second)/3)!!
            return  prvy + druhy == pomocnySucet!!.second
        }
        return true
    }

    fun getSucet(index: Int): Int? = if (index in sucet.indices) sucet[index] else null
    fun getOperator(index: Int): Operator? = if (index in operatory.indices) operatory[index] else null
    fun getOperand(index: Int): Int? = if (index in operandy.indices) operandy[index] else null

    fun setSucet(index: Int, value: Int?) {
        if (index in sucet.indices) {
            sucet[index] = value
        } else {
            throw IndexOutOfBoundsException("Index $index nie je v rozsahu súčtov!")
        }
    }

    fun setOperator(index: Int, value: Operator?) {
        if (index in operatory.indices) {
            operatory[index] = value
        } else {
            throw IndexOutOfBoundsException("Index $index nie je v rozsahu operátorov!")
        }
    }

    fun setOperand(index: Int, value: Int?) {
        if (index in operandy.indices) {
            operandy[index] = value
        } else {
            throw IndexOutOfBoundsException("Index $index nie je v rozsahu operandov!")
        }
    }

    private fun assignUniqueColor(): Color {
        if (availableColors.isEmpty()) {
            throw IllegalStateException("Nie sú k dispozícii žiadne unikátne farby!")
        }
        return availableColors.removeAt(0) // Vyberie a odstráni prvú farbu zo zoznamu
    }

    fun nastavPomocnySucet(index1: Int, index2: Int, sum: Int?) {
        if ((index1 % 3 == 0 ||  index1 % 3 == 2) && (index2 % 3 == 0 ||  index2 % 3 == 2)) {
            pomocnySucet = Pair(Pair(index1, index2), sum)
        } else {
            throw IndexOutOfBoundsException("Indexy nie sú platné!")
        }
    }

    fun nastavNeposedy(neposedy: List<Int>){
        this.neposedy = neposedy
    }

    fun setniSucty(sucet: List<Int?>){
        this.sucet = sucet.toMutableList()
    }

    fun setniOperatory(operatory: List<Operator?>){
        this.operatory = operatory.toMutableList()
    }

    fun setniOperandy(operandy: List<Int?>){
        this.operandy = operandy.toMutableList()
    }


    fun copy(pomocnySucet: Pair<Pair<Int, Int>, Int?>? = this.pomocnySucet, neposedy: List<Int>? = this.neposedy): Had {
        val newHad = Had()
        newHad.inicializujHad(this.sucet.size)

        this.sucet.forEachIndexed { index, value ->
            newHad.setSucet(index, value)
        }
        this.operatory.forEachIndexed { index, operator ->
            if (operator != null) {
                newHad.setOperator(index, operator)
            }
        }
        this.operandy.forEachIndexed { index, operand ->
            if (operand != null) {
                newHad.setOperand(index, operand)
            }
        }

        newHad.pomocnySucet = pomocnySucet

        newHad.neposedy = neposedy

        return newHad
    }

    override fun toString(): String {
        var string = ""
        for (i in 0 until sucet.size-1) {
            if (sucet[i] != null) {
                string += "{${sucet[i]}}"
            } else {
                string += "{ }"
            }
            if (operatory[i] != null) {
                string += "{${Operator.toString(operatory[i]!!)}}"
            } else {
                string += "{ }"
            }
            if (operandy[i] != null) {
                string += "{${operandy[i]}}"
            } else {
                string += "{ }"
            }
        }
        if (sucet.last() != null) {
            string += "{${sucet.last()}}"
        } else {
            string += "{ }"
        }
        string += "pomocny:"
        if (pomocnySucet!= null){
            string += "{${pomocnySucet!!.first.first}}"
            string += "{${pomocnySucet!!.first.second}}"
            string += "{${pomocnySucet!!.second}}"
        } else {
            string += "{ }"
            string += "{ }"
            string += "{ }"
        }
        return string
    }

    fun fromString(encoded: String): Had {
        var had = Had()

        val regex = "\\{(.*?)\\}".toRegex()
        val matches = regex.findAll(encoded).map { it.groupValues[1].trim() }.toList()

        val sucet = mutableListOf<Int?>()
        val operatory = mutableListOf<Operator?>()
        val operandy = mutableListOf<Int?>()

        var index = 0
        while (index < matches.size-1) {
            val sucetValue = matches[index].takeIf { it.isNotEmpty() }?.toIntOrNull()
            sucet.add(sucetValue)
            index++

            if (index < matches.size) {
                val operatorValue = matches[index]
                operatory.add(if (operatorValue.isNotEmpty()) Operator.fromString(operatorValue) else null)
                index++
            }

            if (index < matches.size) {
                val operandValue = matches[index].takeIf { it.isNotEmpty() }?.toIntOrNull()
                operandy.add(operandValue)
                index++
            }
        }

        val sucetValue = matches[index].takeIf { it.isNotEmpty() }?.toIntOrNull()
        sucet.add(sucetValue)

        had.setniSucty(sucet)
        had.setniOperatory(operatory)
        had.setniOperandy(operandy)

        return had
    }

    fun vymazVsetkyHodnoty() {
        for (i in 0 until sucet.size-1) {
            sucet[i] = null
            if (operatory[i] != Operator.REVERSE) {
                operatory[i] = null
            }
            operandy[i] = null
        }
        sucet[sucet.size-1] = null
    }


}


