package com.example.hady.logic

import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import com.example.hady.ui.theme.*
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

enum class Operator(val operation: (Int, Int) -> Int?) {

    ADD({ a, b -> a + b }),
    SUBTRACT({ a, b -> a - b }),
    MULTIPLY({ a, b -> a * b }),
    DIVIDE({ a, b -> if (b != 0) a / b else null }),
    REVERSE({ _, _ -> null });
}

class Had {
    var operatory: MutableList<Operator?> = ArrayList()
    var operandy: MutableList<Int?> = ArrayList()
    var sucet: MutableList<Int?> = ArrayList()
    var buttonColors: MutableList<Color> = ArrayList() // Zoznam farieb pre tlačidlá
    val availableColors = mutableListOf(
        PastelBlue, PastelOrange, PastelPink, PastelGreen, PastelYellow,
        PastelPurple, PastelRed, PastelTeal, PastelBeige, PastelMint
    ) // Zoznam dostupných farieb

    var pomocnySucet by mutableStateOf<Pair<Pair<Int, Int>, Int>?>(null)

    var neposedy by mutableStateOf<List<Int>?>(null)

    fun pridajClen(operator: Operator?, operand: Int?, vysledok: Int?) {
        operatory.add(operator)
        operandy.add(operand)
        sucet.add(vysledok)
        buttonColors.add(assignUniqueColor())
    }

    fun inicializujHad(velkost: Int) {
        sucet.add(null)
        buttonColors.add(assignUniqueColor())
        for (i in 1 until velkost) {
            operatory.add(null)
            operandy.add(null)
            sucet.add(null)
            buttonColors.add(assignUniqueColor())
        }
    }

    fun check(): Boolean {
        if (sucet[0] == null) return false
        var check = sucet[0]
        for (i in operatory.indices) {
            val operator = operatory[i] ?: return false
            Log.d("Had", "Checking operator $operator")
            val operand = operandy[i] ?: return false
            Log.d("Had", "Checking operand $operand")
            val result = sucet[i + 1] ?: return false
            Log.d("Had", "Checking result $result")
            if (operator.operation(check!!, operand) != result) return false
            Log.d("Had", "Checking passed")
            check = result
        }
        if (pomocnySucet!=null){
            val prvy = getSucet((pomocnySucet!!.first.first)/3)!!
            val druhy = getSucet((pomocnySucet!!.first.second)/3)!!
            return  prvy + druhy == pomocnySucet!!.second
        }
        return true
    }

    fun getSucet(index: Int): Int? = if (index in sucet.indices) sucet[index] else null
    fun getOperator(index: Int): Operator? = if (index in operatory.indices) operatory[index] else null
    fun getOperand(index: Int): Int? = if (index in operandy.indices) operandy[index] else null

    fun setSucet(index: Int, value: Int?) {
        if (index in sucet.indices) {
            sucet[index] = value
        } else {
            throw IndexOutOfBoundsException("Index $index nie je v rozsahu súčtov!")
        }
    }

    fun setOperator(index: Int, value: Operator?) {
        if (index in operatory.indices) {
            operatory[index] = value
        } else {
            throw IndexOutOfBoundsException("Index $index nie je v rozsahu operátorov!")
        }
    }

    fun setOperand(index: Int, value: Int?) {
        if (index in operandy.indices) {
            operandy[index] = value
        } else {
            throw IndexOutOfBoundsException("Index $index nie je v rozsahu operandov!")
        }
    }

    private fun assignUniqueColor(): Color {
        if (availableColors.isEmpty()) {
            throw IllegalStateException("Nie sú k dispozícii žiadne unikátne farby!")
        }
        return availableColors.removeAt(0) // Vyberie a odstráni prvú farbu zo zoznamu
    }

    fun nastavPomocnySucet(index1: Int, index2: Int, sum : Int) {
        if ((index1 % 3 == 0 ||  index1 % 3 == 2) && (index2 % 3 == 0 ||  index2 % 3 == 2)) {
            pomocnySucet = Pair(Pair(index1, index2), sum)
        } else {
            throw IndexOutOfBoundsException("Indexy nie sú platné!")
        }
    }

    fun nastavNeposedy(neposedy: List<Int>){
        this.neposedy = neposedy
    }


    fun copy(pomocnySucet: Pair<Pair<Int, Int>, Int>? = this.pomocnySucet, neposedy: List<Int>? = this.neposedy): Had {
        val newHad = Had()
        newHad.inicializujHad(this.sucet.size)

        this.sucet.forEachIndexed { index, value ->
            newHad.setSucet(index, value)
        }
        this.operatory.forEachIndexed { index, operator ->
            if (operator != null) {
                newHad.setOperator(index, operator)
            }
        }
        this.operandy.forEachIndexed { index, operand ->
            if (operand != null) {
                newHad.setOperand(index, operand)
            }
        }

        newHad.pomocnySucet = pomocnySucet

        newHad.neposedy = neposedy

        return newHad
    }


}


