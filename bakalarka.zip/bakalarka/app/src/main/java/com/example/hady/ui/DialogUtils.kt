package com.example.hady.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.EaseOutBounce
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.VectorConverter
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.navigation.NavController
import com.example.hady.ui.theme.*
import com.example.hady.logic.HadViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun ResultDialog(
    isValid: Boolean,
    onDismiss: () -> Unit,
    viewModel: HadViewModel,
    onRetry: () -> Unit,
) {
    val buttonColor = if (isValid) PastelGreen else PastelRed
    val icon = if (isValid) Icons.Filled.Check else Icons.Filled.Refresh // ✔ alebo ↻
    val message = viewModel.editorMessage.value

    // ⏳ Určenie dĺžky zobrazenia dialógu (1s normálne, 3s ak je chybová správa)
    val delayTime = if (!isValid && message.isNotEmpty() && message!="null") 3000L else 1000L

    // 🔥 Automatické zatvorenie po určenom čase
    LaunchedEffect(Unit) {
        delay(delayTime)
        if (isValid) {
            viewModel.nextHad()
        } else {
            onRetry()
        }
        onDismiss()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(25.dp),
        modifier = Modifier.size(250.dp, if (isValid || message == "null") 150.dp else 220.dp), // 🔺 Väčší dialóg pri chybe
        confirmButton = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(0.dp)
            ) {
                // 🟥 Chybová správa nad ikonou
                if (!isValid && message.isNotEmpty() && message!="null") {
                    Text(
                        text = message,
                        color = Color.Black, // ⚫ Čierna farba
                        fontSize = 22.sp, // 🔺 EŠTE väčší text
                        fontWeight = FontWeight.Bold, // 🔺 Tučné písmo
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 20.dp) // 🔺 Väčšia medzera pod textom
                    )
                }

                Button(
                    onClick = {
                        if (isValid) {
                            viewModel.nextHad()
                            onDismiss()
                        } else {
                            onRetry()
                        }
                    },
                    modifier = Modifier
                        .size(170.dp) // 🔺 Väčšie tlačidlo
                        .clip(RoundedCornerShape(50)),
                    colors = ButtonDefaults.buttonColors(containerColor = buttonColor)
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(90.dp) // 🔹 Väčšia ikona
                    )
                }
            }
        }
    )
}



@Composable
fun FinalResultDialog(
    viewModel: HadViewModel,
    progressColor: Color,
    onDismiss: () -> Unit,
    onNext: () -> Unit,
    onEdit: () -> Unit
) {
    val ceruzkaOffset = remember { Animatable(Offset.Zero, Offset.VectorConverter) }
    val screenWidth = with(LocalDensity.current) { LocalConfiguration.current.screenWidthDp.dp.toPx() }
    val statusBarHeight = 100f // Približná výška status baru, uprav podľa potreby
    val coroutineScope = rememberCoroutineScope()

    val initialPosition = remember { mutableStateOf(Offset(100f, 100f)) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = null,
        text = null,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.size(300.dp, 200.dp),
        confirmButton = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                // ✅ ANIMOVANÝ PROGRESS BAR
                val progress = remember { Animatable(0f) }
                LaunchedEffect(Unit) {
                    progress.animateTo(1f, animationSpec = tween(durationMillis = 1500))
                }

                LinearProgressIndicator(
                    progress = progress.value,
                    color = progressColor,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(14.dp)
                        .clip(RoundedCornerShape(50))
                )

                Spacer(modifier = Modifier.height(24.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp) // Obal pre tlačidlá a animáciu
                ) {

                    Button(
                        onClick = { onEdit() }, // Kliknutím na ceruzku sa prepneš do editora
                        modifier = Modifier
                            .size(90.dp)
                            .offset { IntOffset(ceruzkaOffset.value.x.toInt(), ceruzkaOffset.value.y.toInt()) }
                            .graphicsLayer(translationX = ceruzkaOffset.value.x, translationY = ceruzkaOffset.value.y), // Animácia pohybu
                        colors = ButtonDefaults.buttonColors(containerColor = progressColor), // ✅ Pozadie vo farbe progress baru
                        shape = RoundedCornerShape(50)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Edit,
                            contentDescription = "Edit",
                            tint = Color.White, // ✅ Ceruzka je biela
                            modifier = Modifier.size(50.dp)
                        )
                    }

                    // ✅ ŠÍPKA (KEĎ KLIKNEŠ, CERUZKA LETÍ)
                    Button(
                        onClick = {
                            coroutineScope.launch {
                                ceruzkaOffset.animateTo(
                                    Offset(screenWidth - 400f, -1400f), // Let do horného pravého rohu celej obrazovky (nie len dialógu)
                                    animationSpec = tween(600, easing = FastOutSlowInEasing)
                                )
                                onNext() // Pokračovanie na ďalší príklad
                            }
                        },
                        modifier = Modifier
                            .size(90.dp)
                            .align(Alignment.BottomEnd)
                            .clip(RoundedCornerShape(50)),
                        colors = ButtonDefaults.buttonColors(containerColor = PastelGreen)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.ArrowForward,
                            contentDescription = "Next",
                            tint = Color.White,
                            modifier = Modifier.size(50.dp)
                        )
                    }
                }
            }
        }
    )
}

@Composable
fun UnlockLevelDialog(
    newLevel: Int,
    color: Color,
    onDismiss: () -> Unit
) {
    var isAnimating by remember { mutableStateOf(true) }

    val alphaLock by animateFloatAsState(
        targetValue = if (isAnimating) 1f else 0f,
        animationSpec = tween(durationMillis = 1000, easing = FastOutSlowInEasing),
        label = "Lock Alpha"
    )

    val alphaSnakes by animateFloatAsState(
        targetValue = if (isAnimating) 0f else 1f,
        animationSpec = tween(durationMillis = 1000, easing = FastOutSlowInEasing),
        label = "Snakes Alpha"
    )

    val animatedColor by animateColorAsState(
        targetValue = if (isAnimating) Color.Gray else color,
        animationSpec = tween(durationMillis = 1000, easing = FastOutSlowInEasing),
        label = "Button Color"
    )

    LaunchedEffect(Unit) {
        delay(1200) // Čas na animáciu
        isAnimating = false
        delay(800)  // Počkáme na dokončenie
        onDismiss() // Zavrieme dialog
    }

    Dialog(onDismissRequest = {}) {
        Box(
            modifier = Modifier
                .height(80.dp)
                .fillMaxWidth(0.8f)
                .background(animatedColor, RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Filled.Lock,
                contentDescription = "Lock",
                tint = Color.White.copy(alpha = alphaLock),
                modifier = Modifier.size(50.dp)
            )

            Text(
                text = "🐍".repeat(newLevel + 1),
                fontSize = 30.sp,
                color = Color.White.copy(alpha = alphaSnakes)
            )
        }
    }
}




