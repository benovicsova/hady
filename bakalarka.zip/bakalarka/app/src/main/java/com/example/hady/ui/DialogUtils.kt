package com.example.hady.ui

import android.util.Log
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.hady.ui.theme.*
import com.example.hady.logic.HadViewModel
import kotlinx.coroutines.delay

@Composable
fun ResultDialog(
    isValid: Boolean,
    onDismiss: () -> Unit,
    viewModel: HadViewModel,
    onRetry: () -> Unit,
) {
    val buttonColor = if (isValid) PastelGreen else PastelRed
    val icon = if (isValid) Icons.Filled.Check else Icons.Filled.Refresh // ✔ alebo ↻

    // 🔥 Automatické zatvorenie po 1 sekunde
    LaunchedEffect(Unit) {
        delay(1000)
        if (isValid) {
            viewModel.nextHad()
        } else {
            onRetry()
        }
        onDismiss()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = null,
        text = null,
        shape = RoundedCornerShape(25.dp),
        modifier = Modifier.size(200.dp, 120.dp), // 🔹 Menší dialog
        confirmButton = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(0.dp)
            ) {
                Button(
                    onClick = {
                        if (isValid) {
                            viewModel.nextHad()
                            onDismiss()
                        } else {
                            onRetry()
                        }
                    },
                    modifier = Modifier
                        .size(150.dp)
                        .clip(RoundedCornerShape(50)),
                    colors = ButtonDefaults.buttonColors(containerColor = buttonColor)
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(80.dp) // 🔹 Väčšia ikona
                    )
                }
            }
        }
    )
}



@Composable
fun FinalResultDialog(
    viewModel: HadViewModel,
    progressColor: Color,
    onDismiss: () -> Unit,
    onNext: () -> Unit,
    onEdit: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = null,
        text = null,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.size(300.dp, 180.dp),
        confirmButton = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                LinearProgressIndicator(
                    progress = 1f,
                    color = progressColor,
                    modifier = Modifier
                        .fillMaxWidth(1f)
                        .height(14.dp)
                        .clip(RoundedCornerShape(50))
                )

                Spacer(modifier = Modifier.height(24.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Button(
                        onClick = {
                            onNext()
                            onDismiss()
                        },
                        modifier = Modifier
                            .size(90.dp)
                            .clip(RoundedCornerShape(50)),
                        colors = ButtonDefaults.buttonColors(containerColor = PastelGreen)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.ArrowForward,
                            contentDescription = "Next",
                            tint = Color.White,
                            modifier = Modifier.size(50.dp) // Väčšia ikona
                        )
                    }

                    Button(
                        onClick = onEdit,
                        modifier = Modifier
                            .size(90.dp)
                            .clip(RoundedCornerShape(50)),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Gray)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Edit,
                            contentDescription = "Edit",
                            tint = Color.White,
                            modifier = Modifier.size(50.dp)
                        )
                    }
                }
            }
        }
    )
}
