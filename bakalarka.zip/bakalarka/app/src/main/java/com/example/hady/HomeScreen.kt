package com.example.hady.ui

import android.content.Context
import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.times
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.hady.R
import com.example.hady.logic.HadViewModel
import com.example.hady.ui.theme.*

@Composable
fun HomeScreen(navController: NavController, viewModel: HadViewModel) {
    val context = LocalContext.current
    var showDialog by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        viewModel.initializePreferences(context)
    }

    val levels = listOf(PastelBlue, PastelOrange, PastelPink, PastelGreen, PastelYellow)
    val progressList by remember { viewModel.levelProgress }

    val configuration = LocalConfiguration.current
    val isLandscape =
        configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE

    val buttonSize = if (!isLandscape) 60.dp else 30.dp
    val iconSize = if (!isLandscape) 40.dp else 30.dp
    val padding = if (!isLandscape) 15.dp else 20.dp


    Box(modifier = Modifier
        .fillMaxSize()
        .padding(WindowInsets.statusBars.asPaddingValues())) {

        Image(
            painter = painterResource(id = R.drawable.background2),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = padding, end = padding),
            contentAlignment = Alignment.TopEnd
        ) {
            IconButton(
                onClick = { showDialog = true },
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .size(buttonSize)
                    .border(1.dp, Color.Black, shape = RoundedCornerShape(20.dp))
                    .background(PastelYellow, shape = RoundedCornerShape(20.dp))
            ) {
                Icon(
                    imageVector = Icons.Filled.Settings,
                    contentDescription = "Settings",
                    tint = Color.White,
                    modifier = Modifier.size(iconSize)
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            levels.forEachIndexed { index, color ->
                val isUnlocked = index == 0 || (index > 0 && progressList.getOrNull(index - 1) ?: 0f >= 0.5f)
                LevelButton(
                    color = color,
                    progress = progressList[index],
                    onClick = { startLevel(index, navController, viewModel) },
                    enabled = isUnlocked,
                    level = index
                )
            }
        }
    }

    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = null,
            text = {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .wrapContentHeight(),
                    contentAlignment = Alignment.Center
                ) {
                    Button(
                        onClick = {
                            viewModel.resetProgress()
                            showDialog = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PastelRed),
                        modifier = Modifier
                            .padding(0.dp)
                            .size(600.dp, 70.dp)
                    ) {
                        Text(text = "Resetovať hru", fontSize = 25.sp, color = Color.White)
                    }
                }
            },
            confirmButton = {},
            dismissButton = {}
        )
    }
}


@Composable
fun LevelButton(color: Color, progress: Float, onClick: () -> Unit, enabled: Boolean, level: Int) {

    val configuration = LocalConfiguration.current
    val isLandscape =
        configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE

    val buttonHeight = if (!isLandscape) 60.dp else 40.dp
    val fraction = if (!isLandscape) 0.8f else 0.5f
    val padding = if (!isLandscape) 12.dp else 6.dp
    val paddingMedzi = if (!isLandscape) 8.dp else 4.dp
    val progressBarHeight = if (!isLandscape) 12.dp else 6.dp
    val fontSize = if (!isLandscape) 25.sp else 20.sp

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = padding),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .height(buttonHeight)
                .fillMaxWidth(fraction)
                .fillMaxWidth(fraction)
                .background(
                    if (enabled) color else Color.Gray,
                    shape = RoundedCornerShape(12.dp)
                )
                .clickable(enabled = enabled, onClick = onClick)
                .border(1.dp, Color.Black, RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            if (enabled) {
                Text(
                    text = "🐍".repeat(level + 1),
                    fontSize = fontSize,
                    color = Color.White
                )
            } else {
                Icon(
                    imageVector = Icons.Filled.Lock,
                    contentDescription = "Level locked",
                    tint = Color.White,
                    modifier = Modifier.size(30.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(paddingMedzi))

        LinearProgressIndicator(
            progress = progress,
            modifier = Modifier
                .fillMaxWidth(fraction)
                .height(progressBarHeight)
                .clip(RoundedCornerShape(50))
                .border(1.dp, Color.Black, RoundedCornerShape(50.dp)),
            color = if (enabled) color else Color.Gray,
            trackColor = Color.Gray.copy(alpha = 0.3f),
            strokeCap = StrokeCap.Round
        )
    }
}

fun startLevel(level: Int, navController: NavController, viewModel: HadViewModel) {
    viewModel.loadLevel(level)
    navController.navigate("main_screen")
}
