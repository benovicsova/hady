package com.example.hady.ui

import android.content.Context
import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.times
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.hady.R
import com.example.hady.logic.HadViewModel
import com.example.hady.ui.theme.*

@Composable
fun HomeScreen(navController: NavController, viewModel: HadViewModel) {
    val context = LocalContext.current
    var showDialog by remember { mutableStateOf(false) } // 🔥 Stav pre dialóg

    // 🔹 Inicializácia SharedPreferences
    LaunchedEffect(Unit) {
        viewModel.initializePreferences(context)
    }

    val levels = listOf(PastelBlue, PastelOrange, PastelPink, PastelGreen, PastelYellow)
    val progressList by remember { viewModel.levelProgress }

    Box(modifier = Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = R.drawable.background2),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        // 🔹 Ikona Settings vpravo hore
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            contentAlignment = Alignment.TopEnd
        ) {
            IconButton(onClick = { showDialog = true }) { // 👈 Kliknutím zobrazíme dialóg
                Icon(
                    imageVector = Icons.Filled.Settings,
                    contentDescription = "Nastavenia",
                    tint = Color.White,
                    modifier = Modifier.size(48.dp)
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            levels.forEachIndexed { index, color ->
                val isUnlocked = index == 0 || (index > 0 && progressList.getOrNull(index - 1) ?: 0f >= 0.5f)
                LevelButton(
                    color = color,
                    progress = progressList[index],
                    onClick = { startLevel(index, navController, viewModel) },
                    enabled = isUnlocked,
                    level = index
                )
            }
        }
    }

    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false }, // Zatvorí dialóg pri kliknutí mimo
            title = null,
            text = {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .wrapContentHeight(),
                    contentAlignment = Alignment.Center // Vycentrovanie tlačidla
                ) {
                    Button(
                        onClick = {
                            viewModel.resetProgress() // Akcia resetovania progresu
                            showDialog = false // Skryje dialóg po kliknutí
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PastelRed), // Jemnejšia červená
                        modifier = Modifier.padding(16.dp)
                    ) {
                        Text(text = "Resetovať progres", color = Color.White)
                    }
                }
            },
            confirmButton = {},
            dismissButton = {}
        )
    }
}


@Composable
fun LevelButton(color: Color, progress: Float, onClick: () -> Unit, enabled: Boolean, level: Int) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .height(60.dp)
                .fillMaxWidth(0.8f)
                .background(
                    if (enabled) color else Color.Gray,
                    shape = RoundedCornerShape(12.dp)
                )
                .clickable(enabled = enabled, onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            if (enabled) {
                Text(
                    text = "🐍".repeat(level + 1),
                    fontSize = 25.sp,
                    color = Color.White
                )
            } else {
                Icon(
                    imageVector = Icons.Filled.Lock, // Ikona zámku pre zamknuté levely
                    contentDescription = "Level locked",
                    tint = Color.White,
                    modifier = Modifier.size(30.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        LinearProgressIndicator(
            progress = progress,
            modifier = Modifier
                .fillMaxWidth(0.8f)
                .height(8.dp)
                .clip(RoundedCornerShape(50)),
            color = if (enabled) color else Color.Gray, // Progress bar je sivý pre zamknuté levely
            trackColor = Color.Gray.copy(alpha = 0.3f),
            strokeCap = StrokeCap.Round
        )
    }
}

fun startLevel(level: Int, navController: NavController, viewModel: HadViewModel) {
    viewModel.loadLevel(level)
    navController.navigate("main_screen")
}
