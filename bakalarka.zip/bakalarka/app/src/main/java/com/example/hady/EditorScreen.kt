package com.example.hady.ui

import HadUI
import android.util.Log
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.hady.R
import com.example.hady.logic.Had
import com.example.hady.logic.HadViewModel
import com.example.hady.logic.Operator
import com.example.hady.ui.theme.HadyTheme
import kotlinx.coroutines.delay

@Composable
fun EditorScreen(navController: NavController, viewModel: HadViewModel = viewModel()) {

    var hadLength by remember { mutableStateOf(2) }

    var had by viewModel.had
    var hadCopy by viewModel.hadCopy

    var hadState by remember { mutableStateOf(0) }
    var selectedButtonIndex by remember { mutableStateOf(0) }

    LaunchedEffect(Unit) {
        val novyHad = Had().apply { inicializujHad(hadLength) }
        viewModel.had.value = novyHad
        viewModel.hadCopy.value = novyHad.copy()

        if (viewModel.currentLevel == 2) {
            viewModel.had.value.nastavPomocnySucet(0, 3, null)
        }

        selectedButtonIndex = viewModel.getFirstEmptyIndex(novyHad)
    }

    var showHint by remember { mutableStateOf(false) }
    var showIcon by remember { mutableStateOf(false) }
    var isMoving by remember { mutableStateOf(false) }

    val iconSize by animateDpAsState(
        targetValue = if (isMoving) 60.dp else 40.dp,
        animationSpec = tween(durationMillis = 1000, easing = FastOutSlowInEasing)
    )

    val iconOffsetY by animateDpAsState(
        targetValue = if (isMoving) (-395).dp else 0.dp,
        animationSpec = tween(durationMillis = 1500, easing = LinearOutSlowInEasing)
    )

    val iconOffsetX by animateDpAsState(
        targetValue = if (isMoving) 160.dp else 0.dp,
        animationSpec = tween(durationMillis = 1500, easing = LinearOutSlowInEasing)
    )

    LaunchedEffect(Unit) {
        delay(10000)
        showIcon = true
        delay(500)
        isMoving = true
    }

    fun setHadLength(length: Int) {
        hadLength = length
        had = Had().apply { inicializujHad(length) }
        hadCopy = had.copy()
        hadState = 0

        if (viewModel.currentLevel == 2) {
            had.nastavPomocnySucet(0, minOf(3, length - 1), null)
        }

        selectedButtonIndex = 0
    }

    fun resetCurrentHad() {
        if (hadLength == 2) {
            if (hadState == 0) {
                had.setOperator(0, Operator.REVERSE)
                hadState = 1
            } else {
                had.setOperator(0, null)
                hadState = 0
            }
        } else if (hadLength == 3) {
            if (hadState == 0) {
                had.setOperator(0, Operator.REVERSE)
                hadState = 1
            } else if (hadState == 1) {
                had.setOperator(1, Operator.REVERSE)
                hadState = 2
            } else if (hadState == 2) {
                had.setOperator(0, null)
                hadState = 3
            } else {
                had.setOperator(1, null)
                hadState = 0
            }
        } else {
            when (hadState) {
                0 -> {
                    had.setOperator(0, Operator.REVERSE)
                    had.setOperator(1, null)
                    had.setOperator(2, null)
                }

                1 -> {
                    had.setOperator(0, null)
                    had.setOperator(1, Operator.REVERSE)
                    had.setOperator(2, null)
                }

                2 -> {
                    had.setOperator(0, null)
                    had.setOperator(1, null)
                    had.setOperator(2, Operator.REVERSE)
                }

                3 -> {
                    had.setOperator(0, Operator.REVERSE)
                    had.setOperator(1, Operator.REVERSE)
                    had.setOperator(2, null)
                }

                4 -> {
                    had.setOperator(0, Operator.REVERSE)
                    had.setOperator(1, null)
                    had.setOperator(2, Operator.REVERSE)
                }

                5 -> {
                    had.setOperator(0, null)
                    had.setOperator(1, Operator.REVERSE)
                    had.setOperator(2, Operator.REVERSE)
                }

                6 -> {
                    had.setOperator(0, Operator.REVERSE)
                    had.setOperator(1, Operator.REVERSE)
                    had.setOperator(2, Operator.REVERSE)
                }

                7 -> {
                    had.setOperator(0, null)
                    had.setOperator(1, null)
                    had.setOperator(2, null)
                }
            }
            hadState = (hadState + 1) % 8
        }
        hadCopy = had.copy()
        hadCopy.vymazVsetkyHodnoty()
    }

    HadyTheme {
        Box(
            modifier = Modifier.fillMaxSize()
        ) {

            // Pozadie
            Image(
                painter = painterResource(id = R.drawable.background),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

            if (viewModel.currentLevel == 3 && viewModel.editorMode.value == 1 && showIcon) {
                Box(
                    modifier = Modifier
                        .fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    IconButton(
                        onClick = { showHint = true },
                        modifier = Modifier
                            .offset(x = iconOffsetX, y = iconOffsetY)
                            .size(iconSize)
                            .border(1.dp, Color.Black, shape = RoundedCornerShape(20.dp))
                            .background(
                                viewModel.levels[viewModel.currentLevel],
                                shape = RoundedCornerShape(20.dp)
                            )
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.ic_lightbulb),
                            contentDescription = "Hint",
                            modifier = Modifier.size(iconSize - 20.dp) // Ikona sa zväčšuje
                        )
                    }
                }
            }

            if (showHint) {
                AlertDialog(
                    onDismissRequest = { showHint = false },
                    title = {  },
                    text = {
                        Text(
                            "💡Vyplň celého hadíka a neposedy potom vyskáču.",
                            fontSize = 25.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    },
                    confirmButton = {}
                )
            }


            IconButton(
                onClick = {
                    navController.navigate("home_screen")
                    viewModel.editorMode.value = 0
                },
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(top = 30.dp, start = 15.dp)
                    .size(60.dp)
                    .border(1.dp, Color.Black, shape = RoundedCornerShape(20.dp))
                    .background(
                        viewModel.levels[viewModel.currentLevel],
                        shape = RoundedCornerShape(20.dp)
                    )
            ) {
                Icon(
                    imageVector = Icons.Filled.Home,
                    contentDescription = "Home",
                    tint = Color.White,
                    modifier = Modifier.size(40.dp)
                )
            }


            Box(modifier = Modifier.fillMaxSize()) {
                HadUI(
                    had = had,
                    hadCopy = hadCopy,
                    onColorSelected = { _, index ->
                        selectedButtonIndex = index
                    }
                )

                if (viewModel.currentLevel == 2) {
                    SumUI(
                        had = had,
                        viewModel = viewModel,
                        onColorSelected = { _, index ->
                            selectedButtonIndex = index
                        }
                    )
                }
            }


            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter) ,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {

                if (viewModel.editorMode.value == 1) {
                    Row(
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.Bottom,
                        modifier = Modifier
                            .fillMaxHeight(0.72f)
                    ) {
                        Button(
                            onClick = { setHadLength(2) },
                            modifier = Modifier
                                .width(80.dp)
                                .height(50.dp)
                                .border(1.dp, Color.Black, RoundedCornerShape(36.dp)),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (hadLength == 2) Color(0xFFFFEB3B) else Color(0xFFFFF59D)
                            )
                        ) {
                            Text("2", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Color.Black)
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        Button(
                            onClick = { setHadLength(3) },
                            modifier = Modifier
                                .width(80.dp)
                                .height(50.dp)
                                .border(1.dp, Color.Black, RoundedCornerShape(36.dp)),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (hadLength == 3) Color(0xFFFFEB3B) else Color(0xFFFFF59D)
                            )
                        ) {
                            Text("3", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Color.Black)
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        Button(
                            onClick = { setHadLength(4) },
                            modifier = Modifier
                                .width(80.dp)
                                .height(50.dp)
                                .border(1.dp, Color.Black, RoundedCornerShape(36.dp)),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (hadLength == 4) Color(0xFFFFEB3B) else Color(0xFFFFF59D)
                            )
                        ) {
                            Text("4", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Color.Black)
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        IconButton(
                            onClick = { resetCurrentHad() },
                            modifier = Modifier
                                .size(50.dp)
                                .background(Color(0xFFFFEB3B), shape = CircleShape)
                                .border(1.dp, Color.Black, RoundedCornerShape(36.dp))
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Refresh,
                                contentDescription = "Resetovať hada",
                                tint = Color.Black,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                }

                if (viewModel.currentLevel == 3 && viewModel.editorMode.value == 2) {
                    CalculatorScreen2(
                        had = had,
                        hadCopy = hadCopy,
                        selectedButtonIndex = selectedButtonIndex,
                        onSelectButton = { index ->
                            selectedButtonIndex = index
                        },
                        onHadChange = { update ->
                            viewModel.updateHad(update)
                        },
                        navController = null,
                        viewModel = viewModel
                    )
                } else {
                    CalculatorScreen(
                        had = had,
                        hadCopy = hadCopy,
                        selectedButtonIndex = selectedButtonIndex,
                        onSelectButton = { index ->
                            selectedButtonIndex = index
                        },
                        onHadChange = { update ->
                            viewModel.updateHad(update)
                        },
                        navController = null,
                        viewModel = viewModel
                    )
                }
            }
        }
    }

}