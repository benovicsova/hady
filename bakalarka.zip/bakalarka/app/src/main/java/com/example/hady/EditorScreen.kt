package com.example.hady.ui

import HadUI
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.hady.R
import com.example.hady.logic.Had
import com.example.hady.logic.HadViewModel
import com.example.hady.logic.Operator
import com.example.hady.ui.theme.HadyTheme


@Composable
fun EditorScreen(navController: NavController, viewModel: HadViewModel = viewModel()) {
    var hadLength by remember { mutableStateOf(2) }
    var had by remember { mutableStateOf(Had().apply { inicializujHad(hadLength) }) }
    var hadCopy by remember { mutableStateOf(had.copy()) }

    var hadState by remember { mutableStateOf(0) }


    val selectedButtonIndex = remember { mutableStateOf(viewModel.getFirstEmptyIndex(had)) }

    fun setHadLength(length: Int) {
        hadLength = length
        had = Had().apply { inicializujHad(length) }
        hadCopy = had.copy()
        hadState = 0
        selectedButtonIndex.value = viewModel.getFirstEmptyIndex(had)
    }

    fun resetCurrentHad() {
        if (hadLength == 2){
            if (hadState == 0){
                had.setOperator(0, Operator.REVERSE)
                hadState = 1
            } else {
                had.setOperator(0, null)
                hadState = 0
            }
        } else if (hadLength == 3){
            if (hadState == 0 ){
                had.setOperator(0, Operator.REVERSE)
                hadState = 1
            } else if (hadState == 1){
                had.setOperator(1, Operator.REVERSE)
                hadState = 2
            } else if (hadState == 2) {
                had.setOperator(0, null)
                hadState = 3
            } else {
                had.setOperator(1, null)
                hadState = 0
            }
        } else {
            when (hadState) {
                0 -> {
                    had.setOperator(0, Operator.REVERSE)
                    had.setOperator(1, null)
                    had.setOperator(2, null)
                }
                1 -> {
                    had.setOperator(0, null)
                    had.setOperator(1, Operator.REVERSE)
                    had.setOperator(2, null)
                }
                2 -> {
                    had.setOperator(0, null)
                    had.setOperator(1, null)
                    had.setOperator(2, Operator.REVERSE)
                }
                3 -> {
                    had.setOperator(0, Operator.REVERSE)
                    had.setOperator(1, Operator.REVERSE)
                    had.setOperator(2, null)
                }
                4 -> {
                    had.setOperator(0, Operator.REVERSE)
                    had.setOperator(1, null)
                    had.setOperator(2, Operator.REVERSE)
                }
                5 -> {
                    had.setOperator(0, null)
                    had.setOperator(1, Operator.REVERSE)
                    had.setOperator(2, Operator.REVERSE)
                }
                6 -> {
                    had.setOperator(0, Operator.REVERSE)
                    had.setOperator(1, Operator.REVERSE)
                    had.setOperator(2, Operator.REVERSE)
                }
                7 -> {
                    had.setOperator(0, null)
                    had.setOperator(1, null)
                    had.setOperator(2, null)
                }
            }
            hadState = (hadState + 1) % 8
        }
        hadCopy = had.copy()
        selectedButtonIndex.value = viewModel.getFirstEmptyIndex(had)
    }

    HadyTheme {
        Box(
            modifier = Modifier.fillMaxSize().padding(0.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.background),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )


            IconButton(
                onClick = { navController.navigate("home_screen") },
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(16.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Home,
                    contentDescription = "Home",
                    tint = Color.White,
                    modifier = Modifier.size(50.dp)
                )
            }

            HadyTheme {
                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 610.dp),
                    horizontalArrangement = Arrangement.Center
                ) {
                    Button(
                        onClick = { setHadLength(2) },
                        modifier = Modifier
                            .width(80.dp)
                            .height(50.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (hadLength == 2) Color(0xFFFFEB3B) else Color(0xFFFFF59D)
                        )
                    ) {
                        Text(
                            "2",
                            style = MaterialTheme.typography.bodyLarge.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 20.sp,
                                color = Color.Black
                            ),
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Center
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = { setHadLength(3) },
                        modifier = Modifier
                            .width(80.dp)
                            .height(50.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (hadLength == 3) Color(0xFFFFEB3B) else Color(0xFFFFF59D)
                        )
                    ) {
                        Text(
                            "3",
                            style = MaterialTheme.typography.bodyLarge.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 20.sp,
                                color = Color.Black
                            ),
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Center
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = { setHadLength(4) },
                        modifier = Modifier
                            .width(80.dp)
                            .height(50.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (hadLength == 4) Color(0xFFFFEB3B) else Color(0xFFFFF59D)
                        )
                    ) {
                        Text(
                            "4",
                            style = MaterialTheme.typography.bodyLarge.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 20.sp,
                                color = Color.Black
                            ),
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Center
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    IconButton(
                        onClick = { resetCurrentHad() },
                        modifier = Modifier.size(50.dp)
                            .background(Color(0xFFFFEB3B), shape = CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Refresh,
                            contentDescription = "Resetovať hada",
                            tint = Color.Black,
                            modifier = Modifier.size(36.dp)
                        )
                    }


                }

                HadUI(
                    had = had,
                    hadCopy = hadCopy,
                    onColorSelected = { _, index ->
                        selectedButtonIndex.value = index
                    }
                )

                CalculatorScreen(
                    had = had,
                    hadCopy = hadCopy,
                    selectedButtonIndex = selectedButtonIndex.value,
                    onSelectButton = { index -> selectedButtonIndex.value = index },
                    onHadChange = { update ->
                        viewModel.updateHad(update)
                        selectedButtonIndex.value = viewModel.getFirstEmptyIndex(had)
                    },
                    navController = null,
                    viewModel = viewModel
                )
            }
        }
    }
}
