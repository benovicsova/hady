package com.example.hady.ui

import HadUI
import android.util.Log
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.hady.R
import com.example.hady.logic.Had
import com.example.hady.logic.HadViewModel
import com.example.hady.logic.Operator
import com.example.hady.ui.theme.HadyTheme
import kotlinx.coroutines.delay

@Composable
fun EditorScreen(navController: NavController, viewModel: HadViewModel = viewModel()) {

    var hadLength by remember { mutableStateOf(2) }

    var had by viewModel.had
    var hadCopy by viewModel.hadCopy

    var hadState by remember { mutableStateOf(0) }
    var selectedButtonIndex by remember { mutableStateOf(0) }

    LaunchedEffect(Unit) {
        val novyHad = Had().apply { inicializujHad(hadLength) }
        viewModel.had.value = novyHad
        viewModel.hadCopy.value = novyHad.copy()

        if (viewModel.currentLevel == 2) {
            viewModel.had.value.nastavPomocnySucet(0, 3, null)
        }

    }

    LaunchedEffect (viewModel.currentHadIndex.value){
        selectedButtonIndex = viewModel.getFirstEmptyIndex(viewModel.had.value)
    }


    var showHint by rememberSaveable { mutableStateOf(false) }
    var showIcon by rememberSaveable { mutableStateOf(false) }
    var isMoving by rememberSaveable { mutableStateOf(false) }

    val statusBarHeight = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val screenWidth = LocalConfiguration.current.screenWidthDp
    val screenHeight = LocalConfiguration.current.screenHeightDp.dp - statusBarHeight

    LaunchedEffect(Unit) {
        delay(10000)
        showIcon = true
        delay(500)
        isMoving = true
    }

    val configuration = LocalConfiguration.current
    val isLandscape =
        configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE

    val buttonSize = if (!isLandscape) 60.dp else 30.dp
    val iconSizee = if (!isLandscape) 40.dp else 30.dp
    val padding = if (!isLandscape) 15.dp else 20.dp

    val targetX = if (!isLandscape) screenWidth.dp/2 - 60.dp + padding else screenWidth.dp/2 - 55.dp + padding
    val targetY = if (!isLandscape) -screenHeight/2 + 60.dp - padding else -screenHeight/2 + 55.dp - padding

    val iconOffsetY by animateDpAsState(
        targetValue = if (isMoving) targetY  else 0.dp,
        animationSpec = tween(durationMillis = 1500, easing = LinearOutSlowInEasing)
    )

    val iconOffsetX by animateDpAsState(
        targetValue = if (isMoving) targetX else 0.dp,
        animationSpec = tween(durationMillis = 1500, easing = LinearOutSlowInEasing)
    )

    val scalingFactor = if (!isLandscape) screenWidth/400f else  screenWidth/700f

    val rowButtonWidth = (80 * scalingFactor).dp
    val rowButtonHeight = (50 * scalingFactor).dp
    val textSize = (30 * scalingFactor).sp

    val fraction = if (!isLandscape) 0.7f else 0.15f

    val iconSize by animateDpAsState(
        targetValue = if (!isLandscape) 40.dp else 30.dp,
        animationSpec = tween(durationMillis = 1000, easing = FastOutSlowInEasing)
    )

    fun setHadLength(length: Int) {
        hadLength = length
        had = Had().apply { inicializujHad(length) }
        hadCopy = had.copy()
        hadState = 0

        if (viewModel.currentLevel == 2) {
            had.nastavPomocnySucet(0, 3, null)
        }

        selectedButtonIndex = 0
    }

    fun resetCurrentHad() {
        if (hadLength == 2) {
            if (hadState == 0) {
                had.setOperator(0, Operator.REVERSE)
                hadState = 1
            } else {
                had.setOperator(0, null)
                hadState = 0
            }
        } else if (hadLength == 3) {
            if (hadState == 0) {
                had.setOperator(0, Operator.REVERSE)
                hadState = 1
            } else if (hadState == 1) {
                had.setOperator(1, Operator.REVERSE)
                hadState = 2
            } else if (hadState == 2) {
                had.setOperator(0, null)
                hadState = 3
            } else {
                had.setOperator(1, null)
                hadState = 0
            }
        } else {
            when (hadState) {
                0 -> {
                    had.setOperator(0, Operator.REVERSE)
                    had.setOperator(1, null)
                    had.setOperator(2, null)
                }

                1 -> {
                    had.setOperator(0, null)
                    had.setOperator(1, Operator.REVERSE)
                    had.setOperator(2, null)
                }

                2 -> {
                    had.setOperator(0, null)
                    had.setOperator(1, null)
                    had.setOperator(2, Operator.REVERSE)
                }

                3 -> {
                    had.setOperator(0, Operator.REVERSE)
                    had.setOperator(1, Operator.REVERSE)
                    had.setOperator(2, null)
                }

                4 -> {
                    had.setOperator(0, Operator.REVERSE)
                    had.setOperator(1, null)
                    had.setOperator(2, Operator.REVERSE)
                }

                5 -> {
                    had.setOperator(0, null)
                    had.setOperator(1, Operator.REVERSE)
                    had.setOperator(2, Operator.REVERSE)
                }

                6 -> {
                    had.setOperator(0, Operator.REVERSE)
                    had.setOperator(1, Operator.REVERSE)
                    had.setOperator(2, Operator.REVERSE)
                }

                7 -> {
                    had.setOperator(0, null)
                    had.setOperator(1, null)
                    had.setOperator(2, null)
                }
            }
            hadState = (hadState + 1) % 8
        }
        hadCopy = had.copy()
        hadCopy.vymazVsetkyHodnoty()
    }

    HadyTheme {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(WindowInsets.statusBars.asPaddingValues())
        ) {

            Image(
                painter = painterResource(id = R.drawable.background),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

            if (viewModel.currentLevel == 3 && viewModel.editorMode.value == 1 && showIcon) {
                Box(
                    modifier = Modifier
                        .fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    IconButton(
                        onClick = { showHint = true },
                        modifier = Modifier
                            .offset(x = iconOffsetX, y = iconOffsetY)
                            .size(iconSize/2*3)
                            .border(1.dp, Color.Black, shape = RoundedCornerShape(20.dp))
                            .background(
                                viewModel.levels[viewModel.currentLevel],
                                shape = RoundedCornerShape(20.dp)
                            )
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.ic_lightbulb),
                            contentDescription = "Hint",
                            modifier = Modifier.size(iconSize)
                        )
                    }
                }
            }

            if (showHint) {
                AlertDialog(
                    onDismissRequest = { showHint = false },
                    title = {  },
                    text = {
                        Text(
                            "💡Vyplň celého hadíka a neposedy potom vyskáču.",
                            fontSize = 25.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    },
                    confirmButton = {}
                )
            }


            IconButton(
                onClick = {
                    navController.navigate("home_screen")
                    viewModel.editorMode.value = 0
                },
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(top = padding, start = padding)
                    .size(buttonSize)
                    .border(1.dp, Color.Black, shape = RoundedCornerShape(20.dp))
                    .background(
                        viewModel.levels[viewModel.currentLevel],
                        shape = RoundedCornerShape(20.dp)
                    )
            ) {
                Icon(
                    imageVector = Icons.Filled.Home,
                    contentDescription = "Home",
                    tint = Color.White,
                    modifier = Modifier.size(iconSizee)
                )
            }


            Box(modifier = Modifier.fillMaxSize()) {
                HadUI(
                    had = had,
                    hadCopy = hadCopy,
                    onColorSelected = { _, index ->
                        selectedButtonIndex = index
                    },
                    viewModel = viewModel
                )

                if (viewModel.currentLevel == 2) {
                    SumUI(
                        had = had,
                        viewModel = viewModel,
                        onColorSelected = { _, index ->
                            selectedButtonIndex = index
                        }
                    )
                }
            }


            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter) ,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {

                if (viewModel.editorMode.value == 1) {
                    Row(
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.Bottom,
                        modifier = Modifier
                            .fillMaxHeight(fraction)
                    ) {
                        Button(
                            onClick = { setHadLength(2) },
                            modifier = Modifier
                                .width(rowButtonWidth)
                                .height(rowButtonHeight)
                                .border(1.dp, Color.Black, RoundedCornerShape(rowButtonHeight)),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (hadLength == 2) Color(0xFFFFEB3B) else Color(0xFFFFF59D)
                            )
                        ) {
                            Text("2", fontWeight = FontWeight.Bold, fontSize = textSize, color = Color.Black)
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        Button(
                            onClick = { setHadLength(3) },
                            modifier = Modifier
                                .width(rowButtonWidth)
                                .height(rowButtonHeight)
                                .border(1.dp, Color.Black, RoundedCornerShape(rowButtonHeight)),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (hadLength == 3) Color(0xFFFFEB3B) else Color(0xFFFFF59D)
                            )
                        ) {
                            Text("3", fontWeight = FontWeight.Bold, fontSize = textSize, color = Color.Black)
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        Button(
                            onClick = { setHadLength(4) },
                            modifier = Modifier
                                .width(rowButtonWidth)
                                .height(rowButtonHeight)
                                .border(1.dp, Color.Black, RoundedCornerShape(rowButtonHeight)),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (hadLength == 4) Color(0xFFFFEB3B) else Color(0xFFFFF59D)
                            )
                        ) {
                            Text("4", fontWeight = FontWeight.Bold, fontSize = textSize, color = Color.Black)
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        IconButton(
                            onClick = { resetCurrentHad() },
                            modifier = Modifier
                                .size(rowButtonHeight)
                                .background(Color(0xFFFFEB3B), shape = CircleShape)
                                .border(1.dp, Color.Black, RoundedCornerShape(rowButtonHeight))
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Refresh,
                                contentDescription = "Resetovať hada",
                                tint = Color.Black,
                                modifier = Modifier.size(rowButtonHeight/3*2)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                }

                if (viewModel.currentLevel == 3 && viewModel.editorMode.value == 2) {
                    CalculatorScreen2(
                        had = had,
                        hadCopy = hadCopy,
                        selectedButtonIndex = selectedButtonIndex,
                        onSelectButton = { index ->
                            selectedButtonIndex = index
                        },
                        onHadChange = { update ->
                            viewModel.updateHad(update)
                        },
                        navController = null,
                        viewModel = viewModel
                    )
                } else {
                    CalculatorScreen(
                        had = had,
                        hadCopy = hadCopy,
                        selectedButtonIndex = selectedButtonIndex,
                        onSelectButton = { index ->
                            selectedButtonIndex = index
                        },
                        onHadChange = { update ->
                            viewModel.updateHad(update)
                        },
                        navController = null,
                        viewModel = viewModel
                    )
                }
            }
        }
    }

}