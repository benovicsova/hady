package com.example.hady.ui

import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.hady.logic.Had
import com.example.hady.logic.HadViewModel
import com.example.hady.ui.theme.*

@Composable
fun SumUI(
    had: Had,
    viewModel: HadViewModel,
    onColorSelected: (Color, Int) -> Unit
) {
    val pomocnySucet = viewModel.had.value.pomocnySucet


    val pastelColors = mutableListOf(
        PastelBlue, PastelOrange, PastelPink, PastelGreen, PastelYellow,
        PastelPurple, PastelRed, PastelTeal, PastelBeige, PastelMint
    )

    if (pomocnySucet != null) {
        val index1 = pomocnySucet.first.first
        val index2 = pomocnySucet.first.second
        val sum = pomocnySucet.second
        val color1 = pastelColors.getOrNull(index1) ?: Color.Gray
        val color2 = pastelColors.getOrNull(index2) ?: Color.Gray

        Box(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .fillMaxHeight(0.6f)
                .padding(WindowInsets.statusBars.asPaddingValues()),
            contentAlignment = Alignment.BottomEnd
        ) {
            Row(
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.End)
            ) {
                Box(
                    modifier = Modifier
                        .size(50.dp)
                        .clip(RoundedCornerShape(50.dp))
                        .border(1.dp, Color.Black, RoundedCornerShape(24.dp))
                ) {
                    Button(
                        onClick = {
                            onColorSelected(color1, index1)
                        },
                        modifier = Modifier.fillMaxSize(),
                        colors = ButtonDefaults.buttonColors(containerColor = color1)
                    ) {}

                    Text(
                        text = had.sucet[index1 / 3]?.toString() ?: "",
                        style = TextStyle(
                            color = Color.Black,
                            fontWeight = FontWeight.Bold,
                            fontSize = 30.sp,
                            textAlign = TextAlign.Center
                        ),
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(6.dp)
                    )
                }

                Text(
                    text = "+",
                    style = TextStyle(
                        fontSize = 30.sp,
                        fontWeight = FontWeight.Bold
                    ),
                    modifier = Modifier.align(Alignment.CenterVertically)
                )

                Box(
                    modifier = Modifier
                        .size(50.dp)
                        .clip(RoundedCornerShape(50.dp))
                        .border(1.dp, Color.Black, RoundedCornerShape(24.dp))
                ) {
                    Button(
                        onClick = {
                            onColorSelected(color2, index2)
                        },
                        modifier = Modifier.fillMaxSize(),
                        colors = ButtonDefaults.buttonColors(containerColor = color2)
                    ) {}

                    Text(
                        text = had.sucet[index2 / 3]?.toString() ?: "",
                        style = TextStyle(
                            color = Color.Black,
                            fontWeight = FontWeight.Bold,
                            fontSize = 30.sp,
                            textAlign = TextAlign.Center
                        ),
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(6.dp)
                    )
                }

                if (viewModel.editorMode.value == 1) {

                    Text(
                        text = "=",
                        style = TextStyle(
                            fontSize = 30.sp,
                            fontWeight = FontWeight.Bold
                        ),
                        modifier = Modifier.align(Alignment.CenterVertically)
                    )

                    Box(
                        modifier = Modifier
                            .size(50.dp)
                            .clip(RoundedCornerShape(50.dp))
                            .border(1.dp, Color.Black, RoundedCornerShape(24.dp))
                    ) {
                        Button(
                            onClick = {
                                onColorSelected(Color.White, -1)
                                      },
                            modifier = Modifier
                                .fillMaxSize()
                                .alpha(0.5f) ,
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White)
                        ) {}

                        Text(
                            text = pomocnySucet.second?.toString() ?: "",
                            style = TextStyle(
                                color = Color.Black,
                                fontWeight = FontWeight.Bold,
                                fontSize = 30.sp,
                                textAlign = TextAlign.Center
                            ),
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(6.dp)
                        )
                    }
                } else {
                    Text(
                        text = "= $sum",
                        style = TextStyle(
                            fontSize = 30.sp,
                            fontWeight = FontWeight.Bold
                        ),
                        modifier = Modifier.align(Alignment.CenterVertically)
                    )
                }
            }
        }
    }
}
